-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2021 at 11:56 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `opencart2`
--

-- --------------------------------------------------------

--
-- Table structure for table `oc_credit_config`
--

CREATE TABLE `oc_credit_config` (
  `id` int(11) NOT NULL,
  `merchent` varchar(50) NOT NULL,
  `minCharge` int(11) NOT NULL,
  `maxCharge` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `oc_credit_config`
--

INSERT INTO `oc_credit_config` (`id`, `merchent`, `minCharge`, `maxCharge`, `status`) VALUES
(1, 'X-X-X-X', 1000, 1000000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `oc_credit_purchases`
--

CREATE TABLE `oc_credit_purchases` (
  `id` int(11) UNSIGNED NOT NULL,
  `amount` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oc_credit_transactions`
--

CREATE TABLE `oc_credit_transactions` (
  `id` int(11) UNSIGNED NOT NULL,
  `amount` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `oc_customer_credit`
--

CREATE TABLE `oc_customer_credit` (
  `customer_id` int(11) NOT NULL,
  `balance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `oc_credit_purchases`
--
ALTER TABLE `oc_credit_purchases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oc_credit_transactions`
--
ALTER TABLE `oc_credit_transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `oc_credit_purchases`
--
ALTER TABLE `oc_credit_purchases`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `oc_credit_transactions`
--
ALTER TABLE `oc_credit_transactions`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
