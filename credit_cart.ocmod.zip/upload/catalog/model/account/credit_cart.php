<?php
class ModelAccountCreditCart extends Model{
    public function checkUser(){
        $user_id = $this->customer->getId();
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "customer_credit WHERE customer_id='{$this->db->escape($user_id)}'")->row['total'];
        if(!$check){
            $this->db->query("INSERT INTO " .  DB_PREFIX. "customer_credit (customer_id,balance) VALUES('{$this->db->escape($user_id)}','0')");
        }
        $this->checkTransactions();
    }
    public function checkTransactions(){
        $now = time();
        $exp = $now - 1200;
        $exp_date = date("Y-m-d H:i:s",$exp);
        $this->db->query("UPDATE " . DB_PREFIX . "credit_transactions SET status = '2' WHERE created_at > '$exp_date' AND status = '0'");
    }
    public function getUserBalance($user_id){
        $this->checkUser();
        $balance = (int) $this->db->query("SELECT balance FROM " . DB_PREFIX . "customer_credit WHERE customer_id={$this->db->escape($user_id)}")->row['balance'];
        return $balance;
    }
    public function getChargeHistory($user_id){
        $this->checkUser();
        $charges = $this->db->query("SELECT * FROM " . DB_PREFIX . "credit_transactions WHERE customer_id='{$this->db->escape($user_id)}' ORDER BY created_at DESC")->rows;
        return $charges;
    }
    public function countCharges($user_id){
        $this->checkUser();
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "credit_transactions WHERE customer_id='{$this->db->escape($user_id)}'")->row['total'];
        return $total;
    }
    public function getAmountMin(){
        $this->checkUser();
        $min = (int) $this->db->query("SELECT minCharge FROM " . DB_PREFIX . "credit_config")->row['minCharge'];
        return $min;
    }
    public function getAmountMax(){
        $this->checkUser();
        $max = (int) $this->db->query("SELECT maxCharge FROM " . DB_PREFIX . "credit_config")->row['maxCharge'];
        return $max;
    }
    public function getMerchant(){
        $this->checkUser();
        $merchant = $this->db->query("SELECT merchent FROM " . DB_PREFIX . "credit_config")->row['merchent'];
        return $merchant;
    }
    public function zarinpalRequest($amount){
        $this->checkUser();
        $user_id = $this->customer->getId();
        $now = date("Y-m-d H:i:s");
        $data = [
            "merchant_id" => $this->getMerchant(),
            "amount" => $amount,
            "callback_url" => $this->url->link('account/charge_credit/verify','',true),
            "description" => "شارژ اکانت",
        ];
        $jsonData = json_encode($data);
        $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/request.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v1');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ));
        $result = curl_exec($ch);
        $err = curl_error($ch);
        $result = json_decode($result, true, JSON_PRETTY_PRINT);
        curl_close($ch);

        if ($err) {
            return $err;
        } else {
            if (empty($result['errors'])) {
                if ($result['data']['code'] == 100) {
                    $this->session->data['amount'] = $amount;
                    $this->db->query("INSERT INTO " . DB_PREFIX . "credit_transactions (amount,status,customer_id,created_at) VALUES('{$this->db->escape($amount)}','0','{$this->db->escape($user_id)}','{$now}')");
                    $this->response->redirect("https://www.zarinpal.com/pg/StartPay/" . $result['data']["authority"]);
                }
            } else {
                return $result['errors']['code'];
            }
        }
    }
    public function zarinpalVerify(){
        $this->checkUser();
        $user_id = $this->customer->getId();
        $now = date("Y-m-d H:i:s");
        $Authority = $this->request->get['Authority'];
        $data = [
            "merchant_id" => $this->getMerchant(),
            "authority" => $Authority,
            "amount" => $this->session->data['amount']
        ];
        $jsonData = json_encode($data);
        $ch = curl_init('https://api.zarinpal.com/pg/v4/payment/verify.json');
        curl_setopt($ch, CURLOPT_USERAGENT, 'ZarinPal Rest Api v4');
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ));

        $result = curl_exec($ch);
        curl_close($ch);
        $result = json_decode($result, true);

        if ($err) {
            unset($this->session->data['amount']);
            return [
                'error',
                $err
            ];
        } else {
            if ($result['data']['code'] == 100) {
                $user_id = $this->customer->getId();
                $amount = $this->session->data['amount'];
                $balance = (int) $this->db->query("SELECT balance FROM " . DB_PREFIX . "customer_credit WHERE customer_id='{$this->db->escape($user_id)}'")->row['balance'];
                $balance += $amount;
                $this->db->query("UPDATE " . DB_PREFIX . "customer_credit SET balance = '{$this->db->escape($balance)}' WHERE customer_id = '{$this->db->escape($user_id)}'");
                $this->db->query("UPDATE " . DB_PREFIX . "credit_transactions SET status = '1' WHERE customer_id='{$this->db->escape($user_id)}' AND status = '0' AND amount = '{$this->db->escape($amount)}'");
                unset($this->session->data['amount']);
                return [
                    'success',    
                    $result['data']['ref_id']
                ];
            } else {
                $this->db->query("UPDATE " . DB_PREFIX . "credit_transactions SET status = '2' WHERE customer_id='{$this->db->escape($user_id)}' AND status = '0' AND amount = '{$this->db->escape($amount)}'");
                unset($this->session->data['amount']);
                return [
                    'error',
                    $result['errors']['code']
                ];
            }
        }
    }
    public function checkTransactionExist(){
        $this->checkUser();
        $user_id = $this->customer->getId();
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "credit_transactions WHERE customer_id='{$this->db->escape($user_id)}' AND status = '0'")->row['total'];
        return $check > 0;
    }
}