<?php 
class ModelExtensionPaymentCreditCart extends Model {
  	public function getMethod($address) {
		$this->load->language('extension/payment/credit_cart');

		$status = (int) $this->db->query("SELECT status FROM " . DB_PREFIX . "credit_config")->row['status'];

		$method_data = array();
		
		if ($status) {
      		$method_data = array( 
        		'code'       => 'credit_cart',
        		'title'      => $this->language->get('text_title'),
				'terms'      => '',
				'sort_order' => 0
      		);
    	}
		
    	return $method_data;
  	}
	
	public function pay($amount){
		$user_id = $this->customer->getId();
		$this->db->query("DELETE FROM " . DB_PREFIX . "cart WHERE customer_id = '{$this->db->escape($user_id)}'");
		$balance = (int) $this->db->query("SELECT balance FROM " . DB_PREFIX . "customer_credit WHERE customer_id='{$this->db->escape($user_id)}'")->row['balance'];
		if($balance >= $amount){
			$balance = $balance - $amount;
			$this->db->query("UPDATE " . DB_PREFIX . "customer_credit SET balance = '{$this->db->escape($balance)}' WHERE customer_id='{$this->db->escape($user_id)}'");
			return true;
		} else{
			return false;
		}
	}

	public function addPurchases($amount,$status,$order_id){
		$user_id = $this->customer->getId();
		$now = time();
		$now_date = date("Y-m-d H:i:s",$now);
		$this->db->query("INSERT INTO " . DB_PREFIX . "credit_purchases (amount,status,order_id,customer_id,created_at) VALUES('{$this->db->escape($amount)}','{$this->db->escape($status)}','{$this->db->escape($order_id)}','{$this->db->escape($user_id)}','{$now_date}')");
	}
}
?>