<?php

$_['heading_title']                 = 'اطلاعات کیف پول';


// Texts
$_['text_account']                  = 'حساب کاربری';
$_['text_credit_cart']              = 'اطلاعات کیف پول';
$_['text_charge']                   = 'موجودی حساب';
$_['text_charge_history']           = 'تاریخچه ی شارژ';
$_['text_amount']                   = 'مبلغ';
$_['text_status']                   = 'وضعیت';
$_['text_status_ok']                = 'موفق';
$_['text_status_nok']               = 'ناموفق';
$_['text_status_wait']              = 'در انتظار تایید';
$_['text_date']                     = 'تاریخ';

// Errors
$_['error_charges']                 = 'داده ای برای نمایش وجود ندارد';