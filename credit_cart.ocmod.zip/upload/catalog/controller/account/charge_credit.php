<?php
class ControllerAccountChargeCredit extends Controller {
	private $error;
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/charge_credit', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/charge_credit');
		$this->load->model('account/credit_cart');
		$data['heading_title'] = $this->language->get('heading_title');
		$this->document->setTitle($data['heading_title']);
		$data['text_amount'] = $this->language->get('text_amount');
		$data['button_payment'] = $this->language->get('button_payment');
		$data['action'] = $this->url->link('account/charge_credit/payment','',true);
		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_charge_credit'),
			'href' => $this->url->link('account/charge_credit', '', true)
		);
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/charge_credit', $data));
	}
	public function payment(){
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/charge_credit', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/charge_credit');
		$this->load->model('account/credit_cart');
		$data['heading_title'] = $this->language->get('heading_title');
		$this->document->setTitle($data['heading_title']);
		$cid = $this->customer->getId();
		$data['text_amount'] = $this->language->get('text_amount');
		$data['button_payment'] = $this->language->get('button_payment');
		$data['action'] = $this->url->link('account/charge_credit/payment','',true);

		if($this->paymentValidate()){
			$payment = $this->model_account_credit_cart->zarinpalRequest($this->request->post['amount']);
			$data['error'] = $payment;
		} else{
			if(isset($this->error['error_amount'])){
				$data['error_amount'] = $this->error['error_amount'];
			}
			if(isset($this->error['error_payment'])){
				$data['error_payment'] = $this->error['error_payment'];
			}
		}
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_charge_credit'),
			'href' => $this->url->link('account/charge_credit', '', true)
		);
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/charge_credit', $data));
	}

	public function verify(){
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/charge_credit', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/charge_credit');
		$this->load->model('account/credit_cart');
		$data['heading_title'] = $this->language->get('heading_title');
		$this->document->setTitle($data['heading_title']);
		$cid = $this->customer->getId();
		$data['text_amount'] = $this->language->get('text_amount');
		$data['button_payment'] = $this->language->get('button_payment');
		$data['action'] = $this->url->link('account/charge_credit/payment','',true);

		if($this->verifyValidate()){
			$result = $this->model_account_credit_cart->zarinpalVerify();
			if($result[0] == 'error'){
				$data['error'] = $result[1];
			} else{
				$data['success'] = $result[1];
			}
		} else{
			if(isset($this->error['error_authority'])){
				$data['error'] = $this->error['error_authority'];
			} elseif(isset($this->error['error_amount'])){
				$data['error'] = $this->error['error_amount'];
			}
		}

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_charge_credit'),
			'href' => $this->url->link('account/charge_credit', '', true)
		);
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/charge_credit', $data));
	}

	protected function paymentValidate(){
		if(!isset($this->request->post['amount']) || empty($this->request->post['amount']) || !is_numeric($this->request->post['amount'])){
			$this->error['error_amount'] = $this->language->get('error_amount');
		} elseif((int) $this->request->post['amount'] < $this->model_account_credit_cart->getAmountMin()){
			$this->error['error_amount'] = $this->language->get('error_min_amount');
		} elseif((int) $this->request->post['amount'] > $this->model_account_credit_cart->getAmountMax()){
			$this->error['error_amount'] = $this->language->get('error_max_amount');
		}
		if($this->model_account_credit_cart->checkTransactionExist()){
			$this->error['error_payment'] = $this->language->get('error_payment');
		}
		return !$this->error;
	}

	protected function verifyValidate(){
		if(!isset($this->request->get['Authority']) || empty($this->request->get['Authority'])){
			$this->error['error_authority'] = $this->language->get('error_authority');
		}
		if(!isset($this->session->data['amount']) || empty($this->session->data['amount']) || !is_numeric($this->session->data['amount'])){
			$this->error['error_amount'] = $this->language->get('error_verify_amount');
		}

		return !$this->error;
	}
}