<?php
class ControllerAccountCreditCart extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/credit_cart', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('account/credit_cart');
		$this->load->model('account/credit_cart');
		$this->load->model('jdate/jdate');
		$this->document->setTitle($this->language->get('heading_title'));
		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_charge'] = $this->language->get('text_charge');
		$data['text_charge_history'] = $this->language->get('text_charge_history');
		$data['text_amount'] = $this->language->get('text_amount');
		$data['text_status'] = $this->language->get('text_status');
		$data['text_status_ok'] = $this->language->get('text_status_ok');
		$data['text_status_nok'] = $this->language->get('text_status_nok');
		$data['text_status_wait'] = $this->language->get('text_status_wait');
		$data['text_date'] = $this->language->get('text_date');
		$cid = $this->customer->getId();
		$data['balance'] = $this->model_account_credit_cart->getUserBalance($cid) . " تومان";
		$check = $this->model_account_credit_cart->countCharges($cid);
		
		if($check > 0){
			$charges = $this->model_account_credit_cart->getChargeHistory($cid);
			$data['charges'] = array();
			foreach($charges as $charge){
				if($charge['status'] == 0){
					$charge['status'] = $data['text_status_wait'];
				} elseif($charge['status'] == 1){
					$charge['status'] = $data['text_status_ok'];
				} elseif($charge['status'] == 2){
					$charge['status'] = $data['text_status_nok'];
				}
				$data['charges'][] = [
					'id' => $charge['id'],
					'amount' => $charge['amount'] . " تومان",
					'status' => $charge['status'],
					'date' => $this->model_jdate_jdate->jdate("Y-m-d H:i:s",strtotime($charge['created_at']))
				];
			}
		} else{
			$data['error_charges'] = $this->language->get('error_charges');
		}
		
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_account'),
			'href' => $this->url->link('account/account', '', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_credit_cart'),
			'href' => $this->url->link('account/credit_cart', '', true)
		);
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/credit_cart', $data));
	}
}