<?php

class ControllerExtensionPaymentCreditCart extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('extension/payment/credit_cart');
		
    	$data['button_confirm'] = $this->language->get('button_confirm');
		$data['action'] = $this->url->link('extension/payment/credit_cart/check','',true);

		return $this->load->view('extension/payment/credit_cart', $data);
	}
	
	public function check(){
		if (!$this->customer->isLogged()) {
			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$this->load->language('extension/payment/credit_cart');
		$this->load->model('extension/payment/credit_cart');
		$this->load->model('checkout/order');

		$data['heading_title'] = $this->language->get('heading_title');

		$order_id = isset($this->session->data['order_id']) ? $this->session->data['order_id'] : 0;
		$order_info = $this->model_checkout_order->getOrder($order_id);
		$amount = $this->correctAmount($order_info);
		$comment = $this->language->get('comment');
		$result = $this->model_extension_payment_credit_cart->pay($amount);
		if($result){
			$this->model_checkout_order->addOrderHistory($order_id, '2', $comment, true);
			$this->model_extension_payment_credit_cart->addPurchases($amount,'1',$order_id);
			$data['success'] = $this->language->get('text_success_pay');
		} else{
			$this->model_checkout_order->addOrderHistory($order_id, '10', $comment, true);
			$this->model_extension_payment_credit_cart->addPurchases($amount,'2',$order_id);
			$data['error'] = $this->language->get('text_error_pay');
		}

		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('checkout/cart', '', true)
		);
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('extension/payment/credit_check',$data));
	}

	public function correctAmount($order_info) {
		$amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
		$amount = round($amount);
		$amount = $this->currency->convert($amount, $order_info['currency_code'], "TOM");
		return (int)$amount;
	}
}
?>
