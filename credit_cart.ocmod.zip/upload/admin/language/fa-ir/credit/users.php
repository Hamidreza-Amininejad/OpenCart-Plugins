<?php
$_['heading_title']                 = 'کیف پول';
$_['text_list']                     = 'کاربران';
$_['edit_text_list']                = 'ویرایش کیف پول کاربر';

//Text
$_['text_user']                     = 'نام کاربر';
$_['text_balance']                  = 'موجودی';
$_['text_action']                   = 'عملیات';
$_['text_edit']                     = 'ویرایش';
$_['user_not_exist']                = 'کاربری برای نمایش وجود ندارد';
$_['text_currency']                 = 'تومان';
$_['button_save']                   = 'ذخیره';

//Error
$_['error_id']                      = 'کاربر مورد نظر یافت نشد';
$_['error_balance']                 = 'موجودی باید به صورت عددی وارد شود';