<?php

$_['heading_title']                 = 'گزارشات';
$_['text_list']                     = 'گزارش خریدها';

// Texts
$_['text_user']                     = 'نام کاربر';
$_['text_amount']                   = 'قیمت نهایی';
$_['text_order']                    = 'کد سفارش';
$_['text_status']                   = 'وضعیت';
$_['text_status_ok']                = 'موفق';
$_['text_status_nok']               = 'ناموفق';
$_['text_status_wait']              = 'در انتظار پرداخت';
$_['text_date']                     = 'تاریخ ایجاد درخواست';

// Errors
$_['error_transaction']             = 'تراکنشی برای مشاهده وجود ندارد';