<?php

//Heading
$_['heading_title']                 = 'کیف پول';

//Texts
$_['text_credit_cart']              = 'کیف پول';
$_['text_success']                  = 'ماژول کیف پول با موفقیت ویرایش شد';
$_['text_status']                   = 'وضعیت';
$_['text_status_enable']            = 'فعال';
$_['text_status_disable']           = 'غیرفعال';
$_['button_save']                   = 'ذخیره';
$_['text_edit']                     = 'ویرایش ماژول کیف پول';

//Errors
$_['error_credit_cart_status']      = 'وضعیت به درستی وارد نشده است';