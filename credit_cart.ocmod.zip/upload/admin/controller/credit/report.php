<?php
class ControllerCreditReport extends Controller{
    private $error;
    public function index(){
        $this->response->redirect($this->url->link('credit/report/charges',"token={$this->session->data['token']}"));
    }
    public function charges(){
        $this->load->language('credit/charge_report');
        $this->load->model('credit/credit');
        $this->load->model('jdate/jdate');

        $data = array();
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['text_user'] = $this->language->get('text_user');
        $data['text_amount'] = $this->language->get('text_amount');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_ok'] = $this->language->get('text_status_ok');
        $data['text_status_nok'] = $this->language->get('text_status_nok');
        $data['text_status_wait'] = $this->language->get('text_status_wait');
        $data['text_date'] = $this->language->get('text_date');
        $check = $this->model_credit_credit->countChargeTransactions();
        if($check > 0){
            $data['charges'] = array();
            $charges = $this->model_credit_credit->getChargeTransactions();
            foreach($charges as $charge){
                if($charge['status'] == 1){
                    $charge['status'] = $data['text_status_ok'];
                } elseif($charge['status'] == 0){
                    $charge['status'] = $data['text_status_wait'];
                } elseif($charge['status'] == 2){
                    $charge['status'] = $data['text_status_nok'];
                }
                $data['charges'][] = [
                    'id' => $charge['id'],
                    'name' => $charge['firstname'] . " " . $charge['lastname'],
                    'amount' => $charge['amount'] . " تومان",
                    'status' => $charge['status'],
                    'date' => $this->model_jdate_jdate->jdate("Y-m-d H:i:s",strtotime($charge['created_at']))
                ];
            }
        } else{
            $data['error_transaction'] = $this->language->get('error_transaction');
        }
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('credit/report/charges',"token={$this->session->data['token']}")
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('credit/charge_report',$data));
    }
    public function purchases(){
        $this->load->language('credit/buy_report');
        $this->load->model('credit/credit');
        $this->load->model('jdate/jdate');

        $data = array();
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['text_user'] = $this->language->get('text_user');
        $data['text_amount'] = $this->language->get('text_amount');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_ok'] = $this->language->get('text_status_ok');
        $data['text_status_nok'] = $this->language->get('text_status_nok');
        $data['text_status_wait'] = $this->language->get('text_status_wait');
        $data['text_date'] = $this->language->get('text_date');
        $data['text_order'] = $this->language->get('text_order');
        $check = $this->model_credit_credit->countBuyTransactions();
        if($check > 0){
            $data['purchases'] = array();
            $purchases = $this->model_credit_credit->getBuyTransactions();
            foreach($purchases as $purchase){
                if($purchase['status'] == 1){
                    $purchase['status'] = $data['text_status_ok'];
                } elseif($purchase['status'] == 0){
                    $purchase['status'] = $data['text_status_wait'];
                } elseif($purchase['status'] == 2){
                    $purchase['status'] = $data['text_status_nok'];
                }
                $data['purchases'][] = [
                    'id' => $purchase['id'],
                    'name' => $purchase['firstname'] . " " . $purchase['lastname'],
                    'order' => $purchase['order_id'],
                    'amount' => $purchase['amount'] . " تومان",
                    'status' => $purchase['status'],
                    'date' => $this->model_jdate_jdate->jdate("Y-m-d H:i:s",strtotime($purchase['created_at']))
                ];
            }
        } else{
            $data['error_transaction'] = $this->language->get('error_transaction');
        }
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('credit/report/purchases',"token={$this->session->data['token']}")
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('credit/buy_report',$data));
    }
}