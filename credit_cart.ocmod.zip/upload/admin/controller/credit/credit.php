<?php
class ControllerCreditCredit extends Controller{
    private $error;
    public function index(){      
        $this->load->language('credit/credit');
        $this->load->model('credit/credit');
        $data = array();
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['button_save'] = $this->language->get('button_save');
        $data['text_zarinpal'] = $this->language->get('text_zarinpal');
        $data['text_min_limit'] = $this->language->get('text_min_limit');
        $data['text_max_limit'] = $this->language->get('text_max_limit');
        $data['text_status_on'] = $this->language->get('text_status_on');
        $data['text_status_off'] = $this->language->get('text_status_off');
        $data['text_status'] = $this->language->get('text_status');
        $data['action'] = $this->url->link('credit/credit/update',"token={$this->session->data['token']}");
        $data['setting'] = $this->model_credit_credit->getSetting();

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('credit/credit', 'token=' . $this->session->data['token'], true)
		);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        
        $this->response->setOutput($this->load->view('credit/credit',$data));
    }

    public function update(){
        $this->load->language('credit/credit');
        $this->load->model('credit/credit');
        if($this->validate()){
            $this->model_credit_credit->editSetting($this->request->post);
            $this->response->redirect($this->url->link('credit/credit',"token={$this->session->data['token']}",true));
        } else{
            $data = array();
            $data['heading_title'] = $this->language->get('heading_title');
            $this->document->setTitle($data['heading_title']);
            $data['text_list'] = $this->language->get('text_list');
            $data['button_save'] = $this->language->get('button_save');
            $data['text_zarinpal'] = $this->language->get('text_zarinpal');
            $data['text_min_limit'] = $this->language->get('text_min_limit');
            $data['text_max_limit'] = $this->language->get('text_max_limit');
            $data['text_status_on'] = $this->language->get('text_status_on');
            $data['text_status_off'] = $this->language->get('text_status_off');
            $data['text_status'] = $this->language->get('text_status');
            $data['action'] = $this->url->link('credit/credit/update',"token={$this->session->data['token']}");
            $data['setting'] = $this->model_credit_credit->getSetting();

            if(isset($this->error['zcode'])){
                $data['error_zcode'] = $this->error['zcode'];
            }
            if(isset($this->error['min'])){
                $data['error_min'] = $this->error['min'];
            }
            if(isset($this->error['max'])){
                $data['error_max'] = $this->error['max'];
            }
            if(isset($this->error['status'])){
                $data['error_status'] = $this->error['status'];
            }

            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
            );

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('credit/credit', 'token=' . $this->session->data['token'], true)
            );
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            
            $this->response->setOutput($this->load->view('credit/credit',$data));
        }
    }

    protected function validate(){
        if(!isset($this->request->post['zcode']) || strlen($this->request->post['zcode']) !== 36 || count(explode('-',$this->request->post['zcode'])) !== 5){
            $this->error['zcode'] = $this->language->get('error_zcode');
        }
        if(!isset($this->request->post['min']) || empty($this->request->post['min']) || !is_numeric($this->request->post['min']) || $this->request->post['min'] < 1000){
            $this->error['min'] = $this->language->get('error_min');
        }
        if(!isset($this->request->post['max']) || empty($this->request->post['max']) || !is_numeric($this->request->post['max']) || $this->request->post['max'] < 1000 || $this->request->post['min'] > $this->request->post['max']){
            $this->error['max'] = $this->language->get('error_max');
        }
        if(!isset($this->request->post['status']) || empty($this->request->post['status'])){
            $this->error['status'] = $this->language->get('error_status');
        } elseif($this->request->post['status'] !== "on" && $this->request->post['status'] !== "off"){
            $this->error['status'] = $this->language->get('error_status');
        }

        return !$this->error;
    }
}