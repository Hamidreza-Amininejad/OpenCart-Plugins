<?php
class ControllerCreditUsers extends Controller{
    private $error;
    public function index(){
        $this->load->model('credit/credit');
        $this->load->language('credit/users');
        $data = array();
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['count_users'] = $this->model_credit_credit->countUsers();
        $data['users'] = $this->model_credit_credit->getUsersBalance();
        $data['text_user'] = $this->language->get('text_user');
        $data['text_balance'] = $this->language->get('text_balance');
        $data['text_action'] = $this->language->get('text_action');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['user_not_exist'] = $this->language->get('user_not_exist');
        $data['edit_action'] = $this->url->link('credit/users/edit',"token={$this->session->data['token']}");
        $data['text_currency'] = $this->language->get('text_currency');

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}",true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('credit/users',"token={$this->session->data['token']}",true)
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('credit/users',$data));
    }

    public function edit(){
        $this->load->model('credit/credit');
        $this->load->language('credit/users');
        $data = array();
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('edit_text_list');
        if($this->validate()){
            $data['user'] = $this->model_credit_credit->getUserBalance($this->request->get['id']);
            $data['action'] = $this->url->link('credit/users/update',"token={$this->session->data['token']}");
            $data['text_user'] = $this->language->get('text_user');
            $data['text_balance'] = $this->language->get('text_balance');
            $data['text_edit'] = $this->language->get('text_edit');
            $data['button_save'] = $this->language->get('button_save');   
        } else{
            $this->response->redirect($this->url->link("credit/users","token={$this->session->data['token']}"));
        }
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}",true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('credit/users',"token={$this->session->data['token']}",true)
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('credit/user_edit',$data));
    }

    public function update(){
        $this->load->language('credit/users');
        $this->load->model('credit/credit');
        if($this->updateValidate()){
            $this->model_credit_credit->updateUserBalance($this->request->get['id'],$this->request->post['balance']);
            $this->response->redirect($this->url->link('credit/users',"token={$this->session->data['token']}"));
        }elseif(isset($this->error['id'])){
            $this->response->redirect($this->url->link('credit/users',"token={$this->session->data['token']}"));
        } else{
            $data = array();
            $data['heading_title'] = $this->language->get('heading_title');
            $this->document->setTitle($data['heading_title']);
            $data['text_list'] = $this->language->get('edit_text_list');
            $data['user'] = $this->model_credit_credit->getUserBalance($this->request->get['id']);
            $data['action'] = $this->url->link('credit/users/update',"token={$this->session->data['token']}");
            $data['text_user'] = $this->language->get('text_user');
            $data['text_balance'] = $this->language->get('text_balance');
            $data['text_edit'] = $this->language->get('text_edit');
            $data['button_save'] = $this->language->get('button_save');
            if(isset($this->error['balance'])){
                $data['error_balance'] = $this->error['balance'];
            }
            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}",true)
            ];
            $data['breadcrumbs'][] = [
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('credit/users',"token={$this->session->data['token']}",true)
            ];
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            $this->response->setOutput($this->load->view('credit/user_edit',$data)); 
        }
    }

    protected function updateValidate(){
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id']) || !$this->model_credit_credit->checkUserExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_id');
        }
        if(!isset($this->request->post['balance']) || empty($this->request->post['balance']) || !is_numeric($this->request->post['balance'])){
            $this->error['balance'] = $this->language->get('error_balance');
        }
        return !$this->error;
    }

    protected function validate(){
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !$this->model_credit_credit->checkUserExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_id');
        }
        return !$this->error;
    }
}