<?php
class ControllerExtensionPaymentCreditCart extends Controller{
    private $error;
    public function index(){
        $this->load->language('extension/payment/credit_cart');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('credit_cart', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');
		$data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
		$data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['button_save'] = $this->language->get('button_save');
        $data['text_edit'] = $this->language->get('text_edit');

        $data['status'] = $this->config->get('credit_cart_status');

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/credit_cart', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/credit_cart', 'token=' . $this->session->data['token'], true);
		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true);

		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/credit_cart', $data));
    }
     protected function validate(){
        if($this->request->post['credit_cart_status'] == 1 && $this->request->post['credit_cart_status'] == 2){
            $this->error['credit_cart_status'] = $this->language->get('error_credit_cart_status');
        }
        return !$this->error;
     }
}