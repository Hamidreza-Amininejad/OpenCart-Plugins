<?php
class ModelCreditCredit extends Model{
    public function getSetting(){
        $setting = $this->db->query("SELECT * FROM " . DB_PREFIX . "credit_config WHERE id='1'")->row;
        return $setting;
    }
    public function editSetting($data){
        if($data['status'] == 'on'){
            $data['status'] = 1;
        } else{
            $data['status'] = 0;
        }
        $this->db->query("UPDATE " . DB_PREFIX . "credit_config SET merchent='{$this->db->escape($data['zcode'])}', minCharge='{$this->db->escape($data['min'])}',maxCharge='{$this->db->escape($data['max'])}', status='{$data['status']}' WHERE id='1'");
    }
    public function getUsersBalance(){
        $users = $this->db->query("SELECT customer.customer_id,customer.firstname, customer.lastname, credit.balance  FROM " . DB_PREFIX . "customer AS customer JOIN " . DB_PREFIX . "customer_credit AS credit ON (customer.customer_id = credit.customer_id)")->rows;
        return $users;
    }
    public function countUsers(){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "customer_credit")->row['total'];
        return $total;
    }
    public function getUserBalance($user_id){
        $user = $this->db->query("SELECT customer.firstname, customer.lastname, credit.balance FROM " . DB_PREFIX . "customer AS customer JOIN " . DB_PREFIX . "customer_credit AS credit ON (customer.customer_id = credit.customer_id) WHERE credit.customer_id = {$this->db->escape($user_id)}")->row;
        return $user;
    }
    public function checkUserExist($user_id){
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "customer_credit WHERE customer_id='{$this->db->escape($user_id)}'")->row['total'];
        return $check > 0;
    }
    public function updateUserBalance($user_id,$balance){
        $this->db->query("UPDATE " . DB_PREFIX . "customer_credit SET balance = '{$this->db->escape($balance)}' WHERE customer_id='{$this->db->escape($user_id)}'");
    }
    public function getChargeTransactions(){
        $charges = $this->db->query("SELECT transaction.*, customer.firstname, customer.lastname FROM " . DB_PREFIX . "credit_transactions AS transaction JOIN " . DB_PREFIX . "customer AS customer ON (transaction.customer_id = customer.customer_id) ORDER BY transaction.created_at DESC")->rows;
        return $charges;
    }
    public function getBuyTransactions(){
        $purchases = $this->db->query("SELECT purchases.*,customer.firstname, customer.lastname FROM " . DB_PREFIX . "credit_purchases AS purchases JOIN " . DB_PREFIX . "customer AS customer ON (purchases.customer_id = customer.customer_id) ORDER BY purchases.created_at DESC")->rows;
        return $purchases;
    }
    public function countChargeTransactions(){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "credit_transactions")->row['total'];
        return $total;
    }
    public function countBuyTransactions(){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "credit_purchases")->row['total'];
        return $total;
    }
}