<?php
class InstallExtension{
    public $admin_path;
    public $catalog_path;
    public function __construct(){
        $this->admin_path = DIR_APPLICATION;
        $this->catalog_path = DIR_APPLICATION . '../catalog/';

        $this->admin_controller_column_left();
        $this->admin_language_common_column_left();
        $this->catalog_controller_account_account();
        $this->catalog_controller_extension_module_account();
        $this->catalog_language_account_account();
        $this->catalog_language_extension_module_account();
        $this->catalog_view_account();
        $this->catalog_view_extension_module_account();
    }
    public function editFile($file_path,$search,$replace){
        if(!file_exists($file_path)){
            return false;
        }
        $file = fopen($file_path,"r");
        $fdata = fread($file,filesize($file_path));
        fclose($file);
        unlink($file_path);
        $result = str_replace(base64_decode($search),base64_decode($replace),$fdata);
        $file = fopen($file_path,"a+");
        fwrite($file,$result);
        fclose($file);
    }

    public function admin_controller_column_left(){
        $file_path = "{$this->admin_path}/controller/common/column_left.php";
        $search = "Ly8gRXh0ZW5zaW9u";
        $data = "Ly8gQ3JlZGl0DQoNCgkJCSRjcmVkaXQgPSBhcnJheSgpOw0KDQoJCQlpZigkdGhpcy0+dXNlci0+aGFzUGVybWlzc2lvbignYWNjZXNzJywnY3JlZGl0L2NyZWRpdCcpKXsNCgkJCQkkY3JlZGl0W10gPSBbDQoJCQkJCSduYW1lJyA9PiAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9jcmVkaXRfc2V0dGluZycpLA0KCQkJCQknaHJlZicgPT4gJHRoaXMtPnVybC0+bGluaygnY3JlZGl0L2NyZWRpdCcsInRva2VuPXskdGhpcy0+c2Vzc2lvbi0+ZGF0YVsndG9rZW4nXX0iLCB0cnVlKSwNCgkJCQkJJ2NoaWxkcmVuJyA9PiBhcnJheSgpDQoJCQkJXTsNCgkJCX0NCg0KCQkJaWYoJHRoaXMtPnVzZXItPmhhc1Blcm1pc3Npb24oJ2FjY2VzcycsJ2NyZWRpdC91c2VycycpKXsNCgkJCQkkY3JlZGl0W10gPSBbDQoJCQkJCSduYW1lJyA9PiAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9jcmVkaXRfdXNlcnMnKSwNCgkJCQkJJ2hyZWYnID0+ICR0aGlzLT51cmwtPmxpbmsoJ2NyZWRpdC91c2VycycsInRva2VuPXskdGhpcy0+c2Vzc2lvbi0+ZGF0YVsndG9rZW4nXX0iLCB0cnVlKSwNCgkJCQkJJ2NoaWxkcmVuJyA9PiBhcnJheSgpDQoJCQkJXTsNCgkJCX0NCg0KCQkJJGNyZWRpdF9yZXBvcnQgPSBhcnJheSgpOw0KDQoJCQlpZigkdGhpcy0+dXNlci0+aGFzUGVybWlzc2lvbignYWNjZXNzJywnY3JlZGl0L3JlcG9ydCcpKXsNCgkJCQkkY3JlZGl0X3JlcG9ydFtdID0gWw0KCQkJCQknbmFtZScgPT4gJHRoaXMtPmxhbmd1YWdlLT5nZXQoJ3RleHRfY3JlZGl0X3JlcG9ydF9jaGFyZ2VzJyksDQoJCQkJCSdocmVmJyA9PiAkdGhpcy0+dXJsLT5saW5rKCdjcmVkaXQvcmVwb3J0L2NoYXJnZXMnLCJ0b2tlbj17JHRoaXMtPnNlc3Npb24tPmRhdGFbJ3Rva2VuJ119IiwgdHJ1ZSksDQoJCQkJCSdjaGlsZHJlbicgPT4gYXJyYXkoKQ0KCQkJCV07DQoJCQl9DQoNCgkJCWlmKCR0aGlzLT51c2VyLT5oYXNQZXJtaXNzaW9uKCdhY2Nlc3MnLCdjcmVkaXQvcmVwb3J0Jykpew0KCQkJCSRjcmVkaXRfcmVwb3J0W10gPSBbDQoJCQkJCSduYW1lJyA9PiAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9jcmVkaXRfcmVwb3J0X3B1cmNoYXNlcycpLA0KCQkJCQknaHJlZicgPT4gJHRoaXMtPnVybC0+bGluaygnY3JlZGl0L3JlcG9ydC9wdXJjaGFzZXMnLCJ0b2tlbj17JHRoaXMtPnNlc3Npb24tPmRhdGFbJ3Rva2VuJ119IiwgdHJ1ZSksDQoJCQkJCSdjaGlsZHJlbicgPT4gYXJyYXkoKQ0KCQkJCV07DQoJCQl9DQoNCgkJCWlmKCRjcmVkaXRfcmVwb3J0KXsNCgkJCQkkY3JlZGl0W10gPSBbDQoJCQkJCSduYW1lJyA9PiAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9jcmVkaXRfcmVwb3J0JyksDQoJCQkJCSdocmVmJyA9PiAnJywNCgkJCQkJJ2NoaWxkcmVuJyA9PiAkY3JlZGl0X3JlcG9ydA0KCQkJCV07CQ0KCQkJfQ0KDQoJCQlpZigkY3JlZGl0KXsNCgkJCQkkZGF0YVsnbWVudXMnXVtdID0gYXJyYXkoDQoJCQkJCSdpZCcgICAgICAgPT4gJ21lbnUtY3JlZGl0JywNCgkJCQkJJ2ljb24nCSAgID0+ICdmYS1jcmVkaXQtY2FyZCcsIA0KCQkJCQknbmFtZScJICAgPT4gJHRoaXMtPmxhbmd1YWdlLT5nZXQoJ3RleHRfY3JlZGl0JyksDQoJCQkJCSdocmVmJyAgICAgPT4gJycsDQoJCQkJCSdjaGlsZHJlbicgPT4gJGNyZWRpdA0KCQkJCSk7CQ0KCQkJfQ0KCQkJDQoJDQoJCQkvLyBFeHRlbnNpb24";
        $this->editFile($file_path,$search,$data);
    }

    public function admin_language_common_column_left(){
        $file_path = "{$this->admin_path}/language/fa-ir/common/column_left.php";
        $search = "JF9bJ3RleHRfb3RoZXJfc3RhdHVzJ10gICAgICAgICAgICAgID0gJ9mI2LbYuduM2Kog2YfYp9uMINiv24zar9ixJzs";
        $data = "JF9bJ3RleHRfb3RoZXJfc3RhdHVzJ10gICAgICAgICAgICAgID0gJ9mI2LbYuduM2Kog2YfYp9uMINiv24zar9ixJzsNCiRfWyd0ZXh0X2NyZWRpdCddICAgICAgICAgICAgICAgICAgICA9ICfaqduM2YEg2b7ZiNmEJzsNCiRfWyd0ZXh0X2NyZWRpdF9zZXR0aW5nJ10gICAgICAgICAgICA9ICfYqtmG2LjbjNmF2KfYqic7DQokX1sndGV4dF9jcmVkaXRfdXNlcnMnXSAgICAgICAgICAgICAgPSAn2qnYp9ix2KjYsdin2YYnOw0KJF9bJ3RleHRfY3JlZGl0X3JlcG9ydCddICAgICAgICAgICAgID0gJ9qv2LLYp9ix2LTYp9iqJzsNCiRfWyd0ZXh0X2NyZWRpdF9yZXBvcnRfY2hhcmdlcyddICAgICA9ICfar9iy2KfYsdi0INi02KfYsdqYJzsNCiRfWyd0ZXh0X2NyZWRpdF9yZXBvcnRfcHVyY2hhc2VzJ10gICA9ICfar9iy2KfYsdi0INiu2LHbjNivJzsg";
        $this->editFile($file_path,$search,$data);
    }

    public function catalog_controller_account_account(){
        $file_path = "{$this->catalog_path}/controller/account/account.php";
        $search = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTs";
        $data = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTsNCgkJJGRhdGFbJ3RleHRfY3JlZGl0X2NhcnQnXSA9ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X2NyZWRpdF9jYXJ0Jyk7DQoJCSRkYXRhWyd0ZXh0X2NyZWRpdF9pbmZvJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9jcmVkaXRfaW5mbycpOw0KCQkkZGF0YVsndGV4dF9jaGFyZ2VfY3JlZGl0J10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9jaGFyZ2VfY3JlZGl0Jyk7";
        $this->editFile($file_path,$search,$data);

        $search = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7";
        $data = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7DQoJCSRkYXRhWydjcmVkaXRfaW5mbyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9jcmVkaXRfY2FydCcsICcnLCB0cnVlKTsNCgkJJGRhdGFbJ2NoYXJnZV9jcmVkaXQnXSA9ICR0aGlzLT51cmwtPmxpbmsoJ2FjY291bnQvY2hhcmdlX2NyZWRpdCcsICcnLCB0cnVlKTs";
        $this->editFile($file_path,$search,$data);
    }

    public function catalog_controller_extension_module_account(){
        $file_path = "{$this->catalog_path}/controller/extension/module/account.php";
        $search = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTs";
        $data = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTsNCgkJJGRhdGFbJ3RleHRfY3JlZGl0X2luZm8nXSA9ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X2NyZWRpdF9pbmZvJyk7DQoJCSRkYXRhWyd0ZXh0X2NoYXJnZV9jcmVkaXQnXSA9ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X2NoYXJnZV9jcmVkaXQnKTs";
        $this->editFile($file_path,$search,$data);

        $search = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7";
        $data = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7DQoJCSRkYXRhWydjcmVkaXRfaW5mbyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9jcmVkaXRfY2FydCcsICcnLCB0cnVlKTsNCgkJJGRhdGFbJ2NoYXJnZV9jcmVkaXQnXSA9ICR0aGlzLT51cmwtPmxpbmsoJ2FjY291bnQvY2hhcmdlX2NyZWRpdCcsICcnLCB0cnVlKTs";
        $this->editFile($file_path,$search,$data);
    }

    public function catalog_language_account_account(){
        $file_path = "{$this->catalog_path}/language/fa-ir/account/account.php";
        $search = "JF9bJ3RleHRfcmVjdXJyaW5nJ10gICAgID0gJ9m+2LHYr9in2K7YqiDZh9in24wg2K/ZiNix2Ycg2KfbjCc7";
        $data = "JF9bJ3RleHRfdHJhbnNhY3Rpb25zJ10gID0gJ9iq2LHYp9qp2YbYtCDZh9inJzsNCiRfWyd0ZXh0X2NyZWRpdF9jYXJ0J10gICA9ICfaqduM2YEg2b7ZiNmEJzsNCiRfWyd0ZXh0X2NyZWRpdF9pbmZvJ10gICA9ICfYp9i32YTYp9i52KfYqiDaqduM2YEg2b7ZiNmEJzsNCiRfWyd0ZXh0X2NoYXJnZV9jcmVkaXQnXSA9ICfYtNin2LHamCDaqdix2K/ZhiDaqduM2YEg2b7ZiNmEJzs";
        $this->editFile($file_path,$search,$data);
    }

    public function catalog_language_extension_module_account(){
        $file_path = "{$this->catalog_path}/language/fa-ir/extension/module/account.php";
        $search = "JF9bJ3RleHRfcmVjdXJyaW5nJ10gICA9ICfZvtix2K/Yp9iu2Kog2YfYp9uMINiv2YjYsdmHINin24wnOw";
        $data = "JF9bJ3RleHRfcmVjdXJyaW5nJ10gICA9ICfZvtix2K/Yp9iu2Kog2YfYp9uMINiv2YjYsdmHINin24wnOw0KJF9bJ3RleHRfY3JlZGl0X2luZm8nXSA9ICfYp9i32YTYp9i52KfYqiDaqduM2YEg2b7ZiNmEJzsNCiRfWyd0ZXh0X2NoYXJnZV9jcmVkaXQnXSA9ICfYtNin2LHamCDaqdix2K/ZhiDaqduM2YEg2b7ZiNmEJzs";
        $this->editFile($file_path,$search,$data);
    }

    public function catalog_view_account(){
        $file_path = "{$this->catalog_path}/view/theme/default/template/account/account.tpl";
        $search = "PGxpPjxhIGhyZWY9Ijw/cGhwIGVjaG8gJHJlY3VycmluZzsgPz4iPjw/cGhwIGVjaG8gJHRleHRfcmVjdXJyaW5nOyA/PjwvYT48L2xpPg0KICAgICAgPC91bD4";
        $data = "PGxpPjxhIGhyZWY9Ijw/cGhwIGVjaG8gJHJlY3VycmluZzsgPz4iPjw/cGhwIGVjaG8gJHRleHRfcmVjdXJyaW5nOyA/PjwvYT48L2xpPg0KICAgICAgPC91bD4NCiAgICAgIDxoMj48P3BocCBlY2hvICR0ZXh0X2NyZWRpdF9jYXJ0ID8+PC9oMj4NCiAgICAgIDx1bCBjbGFzcz0ibGlzdC11bnN0eWxlZCI+DQogICAgICAgIDxsaT48YSBocmVmPSI8P3BocCBlY2hvICRjcmVkaXRfaW5mbyA/PiI+PD9waHAgZWNobyAkdGV4dF9jcmVkaXRfaW5mbyA/PjwvYT48L2xpPg0KICAgICAgICA8bGk+PGEgaHJlZj0iPD9waHAgZWNobyAkY2hhcmdlX2NyZWRpdCA/PiI+PD9waHAgZWNobyAkdGV4dF9jaGFyZ2VfY3JlZGl0ID8+PC9hPjwvbGk+DQogICAgICA8L3VsPg";
        $this->editFile($file_path,$search,$data);
    }

    public function catalog_view_extension_module_account(){
        $file_path = "{$this->catalog_path}/view/theme/default/template/extension/module/account.tpl";
        $search = "PD9waHAgfSA/Pg0KICA8YSBocmVmPSI8P3BocCBlY2hvICRhZGRyZXNzOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+";
        $data = "PD9waHAgfSA/Pg0KICA8YSBocmVmPSI8P3BocCBlY2hvICRjcmVkaXRfaW5mbyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9jcmVkaXRfaW5mbyA/PjwvYT4NCiAgPGEgaHJlZj0iPD9waHAgZWNobyAkY2hhcmdlX2NyZWRpdCA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9jaGFyZ2VfY3JlZGl0ID8+PC9hPg0KICA8YSBocmVmPSI8P3BocCBlY2hvICRhZGRyZXNzOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+";
        $this->editFile($file_path,$search,$data);
    }
}

$install = new InstallExtension();