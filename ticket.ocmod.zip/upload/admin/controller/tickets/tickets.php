<?php
class ControllerTicketsTickets extends Controller{
    private $error;
    public function index(){
        $this->load->model('tickets/tickets');
        $this->load->language('tickets/tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['text_home'] = $this->language->get('text_home');
        $data['text_date'] = $this->language->get('text_date');
        $data['text_cat'] = $this->language->get('text_cat');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_user'] = $this->language->get('text_user');
        $data['text_show'] = $this->language->get('text_show');
        $data['text_action'] = $this->language->get('text_action');

        $count = (int) $this->model_tickets_tickets->countTickets();

        if($count){
           $page = (isset($this->request->get['page'])) ? $this->request->get['page'] : 1;
           $tickets = $this->model_tickets_tickets->getTickets($page);
           $total_tickets = $count;
           $data['tickets'] = array();
           
           foreach($tickets as $ticket){
               if($ticket['status'] == 1){
                $ticket['status'] = $data['text_status_enable'];
               } else{
                $ticket['status'] = $data['text_status_disable'];
               }
               
               $data['tickets'][] = [
                   'ticket_id' => $ticket['ticket_id'],
                   'title' => $ticket['title'],
                   'status' => $ticket['status'],
                   'date' => $ticket['date'],
                   'cat' => $ticket['cat_title'],
                   'username' => $ticket['firstname'] . " " . $ticket['lastname'],
                   'href' => $this->url->link('tickets/show',"id={$ticket['ticket_id']}&token={$this->session->data['token']}")
               ];
           }

        $pagination = new Pagination();
        $pagination->total = $total_tickets;
        $pagination->page = $page;
        $pagination->limit = 10;
        $pagination->url = $this->url->link('tickets/tickets', 'page={page}' . "&token={$this->session->data['token']}", true);

        $data['pagination'] = $pagination->render();
        $data['results'] = sprintf($this->language->get('text_pagination'), ($total_tickets) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($total_tickets - 10)) ? $total_tickets : ((($page - 1) * 10) + 10), $total_tickets, ceil($total_tickets / 10));
        } else{
            $data['error_not_found'] = $this->language->get('error_not_found');
        }

        if(isset($this->error['error_warning'])){
            $data['error_warning'] = $this->error['error_warning'];
        }
        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($data['success']);
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $data['text_home'],
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}",true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('tickets/tickets',"token={$this->session->data['token']}",true)
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('tickets/tickets',$data));
    }
}