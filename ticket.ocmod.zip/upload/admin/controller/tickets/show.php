<?php

class ControllerTicketsShow extends Controller{
    private $error;
    public function index(){
        $this->load->language('tickets/show');
        $this->load->model('tickets/tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_home'] = $this->language->get('text_home');
        $data['text_list'] = $this->language->get('text_list');
        $data['text_date'] = $this->language->get('text_date');
        $data['text_cat'] = $this->language->get('text_cat');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_user'] = $this->language->get('text_user');
        $data['text_action'] = $this->language->get('text_action');
        $data['text_message'] = $this->language->get('text_message');
        $data['text_send'] = $this->language->get('text_send');
        $data['text_message_placeholder'] = $this->language->get('text_message_placeholder');

        if($this->validate()){
            $data['info'] = $this->model_tickets_tickets->getTicketInfo($this->request->get['id']);
            $data['info']['username'] = $data['info']['firstname'] . " " . $data['info']['lastname'];
            $data['categories'] = $this->model_tickets_tickets->getCategories();

            $check = $this->model_tickets_tickets->countTicketMessages($this->request->get['id']);
            $data['action'] = $this->url->link('tickets/show/send',"id={$this->request->get['id']}&token={$this->session->data['token']}");
            if($check > 0){
                $data['messages'] = $this->model_tickets_tickets->getTicketMessages($this->request->get['id']);
            } else{
                $data['error_messages'] = $this->language->get('error_messages');
            }
        } else{
            $data['error_warning'] = $this->error['id'];
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('tickets/tickets',"token={$this->session->data['token']}")
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $data['token'] = $this->session->data['token'];
        $data['status_action'] = $this->url->link("tickets/show/changeStatus",'',true);
        $this->response->setOutput($this->load->view('tickets/show',$data));
    }

    public function send(){
        $this->load->language('tickets/show');
        $this->load->model('tickets/tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        if($this->validateSend()){
            $message = $this->request->post['message'];
            $message = htmlspecialchars_decode($message);
            $ticket_id = $this->request->get['id'];
            $user_id = $this->user->getId();

            $this->model_tickets_tickets->sendMessage($message,$ticket_id,$user_id);
            $this->response->redirect($this->url->link('tickets/show',"id={$this->request->get['id']}&token={$this->session->data['token']}"));
        } else{
            if(isset($this->error['id'])){
                $this->response->redirect($this->url->link('tickets/tickets',"token={$this->session->data['token']}"));
            }
            if(isset($this->error['message'])){
                $data['error_message'] = $this->error['message'];
            }

            if(isset($this->request->post['message'])){
                $data['message_data'] = htmlspecialchars_decode($this->request->post['message']);
            }

            $data['text_home'] = $this->language->get('text_home');
            $data['text_list'] = $this->language->get('text_list');
            $data['text_date'] = $this->language->get('text_date');
            $data['text_cat'] = $this->language->get('text_cat');
            $data['text_title'] = $this->language->get('text_title');
            $data['text_status'] = $this->language->get('text_status');
            $data['text_status_enable'] = $this->language->get('text_status_enable');
            $data['text_status_disable'] = $this->language->get('text_status_disable');
            $data['text_user'] = $this->language->get('text_user');
            $data['text_action'] = $this->language->get('text_action');
            $data['text_message'] = $this->language->get('text_message');
            $data['text_send'] = $this->language->get('text_send');
            $data['text_message_placeholder'] = $this->language->get('text_message_placeholder');

            $data['info'] = $this->model_tickets_tickets->getTicketInfo($this->request->get['id']);
            $data['info']['username'] = $data['info']['firstname'] . " " . $data['info']['lastname'];
            $data['categories'] = $this->model_tickets_tickets->getCategories();

            $check = $this->model_tickets_tickets->countTicketMessages($this->request->get['id']);
            $data['action'] = $this->url->link('tickets/show/send',"id={$this->request->get['id']}&token={$this->session->data['token']}");
            if($check > 0){
                $data['messages'] = $this->model_tickets_tickets->getTicketMessages($this->request->get['id']);
            } else{
                $data['error_messages'] = $this->language->get('error_messages');
            }

            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
            ];
            $data['breadcrumbs'][] = [
                'text' => $data['heading_title'],
                'href' => $this->url->link('tickets/tickets',"token={$this->session->data['token']}")
            ];
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            $data['token'] = $this->session->data['token'];
            $data['status_action'] = $this->url->link("tickets/show/changeStatus",'',true);
            $this->response->setOutput($this->load->view('tickets/show',$data));
        }
    }

    public function changeStatus(){
        $this->load->language('tickets/show');
        $this->load->model('tickets/tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);

        if($this->changeStatusValidate()){
            $tid = $this->request->get['ticket_id'];
            $status = $this->request->get['status'];
            $this->model_tickets_tickets->changeStatus($tid,$status);
        }
    }

    protected function validate(){
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id']) || !$this->model_tickets_tickets->checkTicketExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_id');
        }
        return !$this->error;
    }

    protected function validateSend(){
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id']) || !$this->model_tickets_tickets->checkTicketExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_id');
        }
        if(!isset($this->request->post['message']) || utf8_strlen(strip_tags(htmlspecialchars_decode(trim($this->request->post['message'])))) < 5 || utf8_strlen(strip_tags(htmlspecialchars_decode(trim($this->request->post['message'])))) > 250){
            $this->error['message'] = $this->language->get('error_message');
        }
        return !$this->error;
    }
    protected function changeStatusValidate(){
        if(!isset($this->request->get['ticket_id']) || empty($this->request->get['ticket_id']) || !is_numeric($this->request->get['ticket_id']) || !$this->model_tickets_tickets->checkTicketExist($this->request->get['ticket_id'])){
            $this->error['ticket_id'] = $this->language->get('error_ticket_id');
        }
        if(!isset($this->request->get['status']) || ($this->request->get['status']) != 0 && $this->request->get['status'] != 1){
            $this->error['status'] = $this->language->get('error_status');
        }

        return !$this->error;
    }

}