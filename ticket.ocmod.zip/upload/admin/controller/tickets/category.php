<?php

class ControllerTicketsCategory extends Controller{
    private $error;
    public function index(){
        $this->load->model('tickets/tickets');
        $this->load->language('tickets/category');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['text_home'] = $this->language->get('text_home');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_show'] = $this->language->get('text_show');
        $data['text_action'] = $this->language->get('text_action');
        $data['text_subcat'] = $this->language->get('text_subcat');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_add'] = $this->language->get('text_add');
        $data['text_enable'] = $this->language->get('text_enable');
        $data['text_disable'] = $this->language->get('text_disable');
        $data['add'] = $this->url->link('tickets/category/add',"token={$this->session->data['token']}");

        $count = $this->model_tickets_tickets->countCategory();

        if($count){
            $categories = $this->model_tickets_tickets->getCategories();
            $data['categories'] = array();
            foreach($categories as $category){
                if($category['status'] == 0){
                    $category['status'] = $data['text_status_disable'];
                } else{
                    $category['status'] = $data['text_status_enable'];
                }
                $data['categories'][] = [
                    'category_id' => $category['category_id'],
                    'title' => $category['title'],
                    'status' => $category['status'],
                    'total' => $category['total'],
                    'href' => $this->url->link('tickets/category/edit',"id={$category['category_id']}&token={$this->session->data['token']}")
                ];
            }
        } else{
            $data['error_not_found'] = $this->language->get('error_not_found');
        }

        if(isset($this->error['error_warning'])){
            $data['error_warning'] = $this->error['error_warning'];
        }
        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $data['text_home'],
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('tickets/category',"token={$this->session->data['token']}")
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('tickets/category',$data));
    }

    public function add(){
        $this->load->model('tickets/tickets');
        $this->load->language('tickets/category');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['text_home'] = $this->language->get('text_home');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_save'] = $this->language->get('text_save');
        $data['action'] = $this->url->link('tickets/category/store',"token={$this->session->data['token']}");

        if(isset($this->error['error_warning'])){
            $data['error_warning'] = $this->error['error_warning'];
        }
        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $data['text_home'],
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('tickets/category/add',"token={$this->session->data['token']}")
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('tickets/add_category',$data));
    }

    public function store(){
        $this->load->model('tickets/tickets');
        $this->load->language('tickets/category');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);

        if($this->validate()){
            $this->model_tickets_tickets->addCategory($this->request->post['title'],$this->request->post['status']);
            $this->session->data['success'] = $this->language->get('add_success');
            $this->response->redirect($this->url->link('tickets/category',"token={$this->session->data['token']}"));
        } else{
            $data['text_list'] = $this->language->get('text_list');
            $data['text_home'] = $this->language->get('text_home');
            $data['text_title'] = $this->language->get('text_title');
            $data['text_status'] = $this->language->get('text_status');
            $data['text_status_enable'] = $this->language->get('text_status_enable');
            $data['text_status_disable'] = $this->language->get('text_status_disable');
            $data['text_edit'] = $this->language->get('text_edit');
            $data['text_save'] = $this->language->get('text_save');
            $data['action'] = $this->url->link('tickets/category/store',"token={$this->session->data['token']}");

            if(isset($this->error['error_warning'])){
                $data['error_warning'] = $this->error['error_warning'];
            }
            if(isset($this->error['title'])){
                $data['error_title'] = $this->error['title'];
            }
            if(isset($this->error['status'])){
                $data['status'] = $this->error['status'];
            }
            if(isset($this->session->data['success'])){
                $data['success'] = $this->session->data['success'];
                unset($this->session->data['success']);
            }

            if(isset($this->request->post['title'])){
                $data['title'] = $this->request->post['title'];
            }
            if(isset($this->request->post['status'])){
                $data['status'] = $this->request->post['status'];
            }

            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = [
                'text' => $data['text_home'],
                'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
            ];
            $data['breadcrumbs'][] = [
                'text' => $data['heading_title'],
                'href' => $this->url->link('tickets/category/add',"token={$this->session->data['token']}")
            ];
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            $this->response->setOutput($this->load->view('tickets/add_category',$data));
        }
    }

    public function edit(){
        $this->load->model('tickets/tickets');
        $this->load->language('tickets/category');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_list'] = $this->language->get('text_list');
        $data['text_home'] = $this->language->get('text_home');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_save'] = $this->language->get('text_save');

        if($this->model_tickets_tickets->checkCategoryExist($this->request->get['id'])){
            $data['action'] = $this->url->link('tickets/category/update',"token={$this->session->data['token']}&id={$this->request->get['id']}");
            $category = $this->model_tickets_tickets->getCategory($this->request->get['id']);
            $data['title'] = $category['title'];
            $data['status'] = $category['status'];
        } else{
            $this->response->redirect($this->url->link("tickets/category","token={$this->session->data['token']}"));
        }

        if(isset($this->error['error_warning'])){
            $data['error_warning'] = $this->error['error_warning'];
        }
        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $data['text_home'],
            'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('tickets/category/add',"token={$this->session->data['token']}")
        ];
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('tickets/add_category',$data));
    }

    public function update(){
        $this->load->language('tickets/category');
        $this->load->model('tickets/tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);

        if($this->editValidate() && $this->model_tickets_tickets->checkCategoryExist($this->request->get['id'])){
            $this->model_tickets_tickets->editCategory($this->request->get['id'],$this->request->post['title'],$this->request->post['status']);
            $this->session->data['success'] = $this->language->get('edit_success');
            $this->response->redirect($this->url->link("tickets/category","token={$this->session->data['token']}"));
        } else{
            $data['text_list'] = $this->language->get('text_list');
            $data['text_home'] = $this->language->get('text_home');
            $data['text_title'] = $this->language->get('text_title');
            $data['text_status'] = $this->language->get('text_status');
            $data['text_status_enable'] = $this->language->get('text_status_enable');
            $data['text_status_disable'] = $this->language->get('text_status_disable');
            $data['text_edit'] = $this->language->get('text_edit');
            $data['text_save'] = $this->language->get('text_save');

            if($this->model_tickets_tickets->checkCategoryExist($this->request->get['id'])){
                $data['action'] = $this->url->link('tickets/category/update',"token={$this->session->data['token']}&id={$this->request->get['id']}");
                $category = $this->model_tickets_tickets->getCategory($this->request->get['id']);
                $data['title'] = $category['title'];
                $data['status'] = $category['status'];
            } else{
                $this->response->redirect($this->url->link("tickets/category","token={$this->session->data['token']}"));
            }

            if(isset($this->error['error_warning'])){
                $data['error_warning'] = $this->error['error_warning'];
            }
            if(isset($this->error['title'])){
                $data['error_title'] = $this->error['title'];
            }
            if(isset($this->error['status'])){
                $data['error_status'] = $this->error['status'];
            }
            if(isset($this->session->data['success'])){
                $data['success'] = $this->session->data['success'];
                unset($this->session->data['success']);
            }
            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = [
                'text' => $data['text_home'],
                'href' => $this->url->link('common/dashboard',"token={$this->session->data['token']}")
            ];
            $data['breadcrumbs'][] = [
                'text' => $data['heading_title'],
                'href' => $this->url->link('tickets/category/add',"token={$this->session->data['token']}")
            ];
            $data['header'] = $this->load->controller('common/header');
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['footer'] = $this->load->controller('common/footer');
            $this->response->setOutput($this->load->view('tickets/add_category',$data));
        }
    }

    protected function validate(){
        if(!isset($this->request->post['title']) || empty($this->request->post['title']) || utf8_strlen($this->request->post['title']) < 5 || utf8_strlen($this->request->post['title']) > 20){
            $this->error['title'] = $this->language->get('error_title');
        }

        if(!isset($this->request->post['status']) || ($this->request->post['status'] != 0 && $this->request->post['status'] != 1)){
            $this->error['status'] = $this->language->get('error_status');
        }
        return !$this->error;
    }

    protected function editValidate(){
        if(!isset($this->request->post['title']) || empty($this->request->post['title']) || utf8_strlen($this->request->post['title']) < 5 || utf8_strlen($this->request->post['title']) > 20){
            $this->error['title'] = $this->language->get('error_title');
        }
        if(!isset($this->request->post['status']) || ($this->request->post['status'] != 0 && $this->request->post['status'] != 1)){
            $this->error['status'] = $this->language->get('error_status');
        }
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_id');
        }
        return !$this->error;
    }
}