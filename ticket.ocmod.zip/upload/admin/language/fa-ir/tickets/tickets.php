<?php

$_['heading_title']                 = 'تیکت ها';

// Texts
$_['text_list']                     = 'تیکت ها';
$_['text_home']                     = 'پنل مدیریت';
$_['text_date']                     = 'تاریخ ایجاد';
$_['text_cat']                      = 'موضوع';
$_['text_title']                    = 'عنوان';
$_['text_status']                   = 'وضعیت';
$_['text_status_enable']            = 'فعال';
$_['text_status_disable']           = 'غیرفعال';
$_['text_user']                     = 'کاربر';
$_['text_show']                     = 'مشاهده';
$_['text_action']                   = 'عملیات';

// Error
$_['error_not_found']               = 'هیچ داده ای برای نمایش وجود ندارد';
$_['error_ticket_id']               = 'آیدی تیکت مورد نظر به درستی وارد نشده است';
$_['error_status']                  = 'وضعیت تیکت به درستی وارد نشده است';