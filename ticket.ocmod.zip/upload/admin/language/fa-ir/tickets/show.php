<?php

$_['heading_title']                 = 'مشاهده تیکت';

// Texts
$_['text_list']                     = 'درخواست پشتیبانی';
$_['text_home']                     = 'پنل مدیریت';
$_['text_date']                     = 'تاریخ ایجاد';
$_['text_cat']                      = 'موضوع';
$_['text_title']                    = 'عنوان';
$_['text_status']                   = 'وضعیت';
$_['text_status_enable']            = 'فعال';
$_['text_status_disable']           = 'غیرفعال';
$_['text_user']                     = 'کاربر';
$_['text_action']                   = 'عملیات';
$_['text_message']                  = 'پیام';
$_['text_send']                     = 'ارسال';
$_['text_message_placeholder']      = 'پیام خود را وارد کنید';

// Error
$_['error_id']                      = 'تیکت مورد نظر در سیستم یافت نشد';
$_['error_message']                 = 'پیام وارد شده باید بیشتر از 5 حرف و کمتر از 250 حرف داشته باشد';