<?php
class ModelTicketsTickets extends Model{
    public function countTickets(){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket")->row['total'];
        return $total;
    }

    public function getTickets($page){
        $offset = ($page - 1) * 10;
        $tickets = $this->db->query("SELECT ticket.*, cat.title AS cat_title, customer.firstname,customer.lastname FROM " . DB_PREFIX . "ticket AS ticket JOIN " . DB_PREFIX . "ticket_category AS cat ON (ticket.category_id = cat.category_id) JOIN " . DB_PREFIX . "customer AS customer ON (ticket.user_id = customer.customer_id) LIMIT 10 OFFSET {$offset}")->rows;
        return $tickets;
    }

    public function countCategory(){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket_category")->row['total'];
        return $total;
    }

    public function getCategories(){
        $categories = $this->db->query("SELECT * FROM " . DB_PREFIX . "ticket_category")->rows;
        $result = array();
        foreach($categories as $category){
            $result[] = [
                'category_id' => $category['category_id'],
                'title' => $category['title'],
                'status' => $category['status'],
                'total' => $this->countCategoryById($category['category_id'])
            ];
        }
        return $result;
    }

    public function countCategoryById($cid){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket WHERE category_id='{$this->db->escape($cid)}'")->row['total'];
        return $total;
    }

    public function addCategory($title,$status){
        $this->db->query("INSERT INTO " . DB_PREFIX . "ticket_category (title,status) VALUES('{$this->db->escape($title)}','{$this->db->escape($status)}')");
    }

    public function checkCategoryExist($cid){
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket_category WHERE category_id = '{$this->db->escape($cid)}'")->row['total'];
        return $check > 0;
    }

    public function getCategory($cid){
        $category = $this->db->query("SELECT * FROM " . DB_PREFIX . "ticket_category WHERE category_id='{$this->db->escape($cid)}'")->row;
        return $category;
    }

    public function editCategory($cid,$title,$status){
        $this->db->query("UPDATE " . DB_PREFIX . "ticket_category SET title = '{$this->db->escape($title)}', status = '{$this->db->escape($status)}' WHERE category_id='{$this->db->escape($cid)}'");
    }

    public function getTicketInfo($tid){
        $info = $this->db->query("SELECT ticket.*,category.title AS category_title ,customer.firstname, customer.lastname FROM " . DB_PREFIX . "ticket AS ticket JOIN oc_ticket_category AS category ON (category.category_id = ticket.category_id) JOIN " . DB_PREFIX . "customer AS customer ON (customer.customer_id = ticket.user_id) WHERE ticket.ticket_id = '{$this->db->escape($tid)}'")->row;
        return $info;
    }

    public function checkTicketExist($tid){
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket WHERE ticket_id='{$this->db->escape($tid)}'")->row['total'];
        return $check > 0;
    }

    public function getTicketMessages($tid){
        $messages = $this->db->query("SELECT * FROM " . DB_PREFIX . "ticket_message WHERE ticket_id='{$this->db->escape($tid)}' ORDER BY date ASC")->rows;
        return $messages;
    }

    public function countTicketMessages($tid){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket_message WHERE ticket_id='{$this->db->escape($tid)}'")->row['total'];
        return $total;
    }

    public function sendMessage($message,$tid,$uid){
        $now = date("Y-m-d H:i:s");
        $this->db->query("INSERT INTO " . DB_PREFIX . "ticket_message (ticket_id,message,date,user_id,user_type) VALUES('{$this->db->escape($tid)}','{$this->db->escape($message)}','{$now}','{$this->db->escape($uid)}','admin')");
    }

    public function changeStatus($tid,$status){
        $this->db->query("UPDATE " . DB_PREFIX . "ticket SET status = '{$this->db->escape($status)}' WHERE ticket_id= '{$this->db->escape($tid)}'");
    }
}