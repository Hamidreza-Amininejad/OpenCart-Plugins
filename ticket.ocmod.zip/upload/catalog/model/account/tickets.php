<?php

class ModelAccountTickets extends Model{
    public function countCustomerTickets($cid){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket WHERE user_id='{$this->db->escape($cid)}'")->row['total'];
        return $total;
    }

    public function checkCustomerAccess($cid,$tid){
        $customer_id = (int) $this->db->query("SELECT user_id FROM " . DB_PREFIX . "ticket WHERE ticket_id='{$this->db->escape($tid)}'")->row['user_id'];
        return $cid == $customer_id;
    }

    public function getTickets($cid,$page){
        $offset = ($page - 1) * 10;
        $tickets = $this->db->query("SELECT ticket.*,cat.title AS category_title, customer.firstname, customer.lastname FROM " . DB_PREFIX . "ticket AS ticket JOIN " . DB_PREFIX . "ticket_category AS cat ON (ticket.category_id = cat.category_id) JOIN " . DB_PREFIX . "customer AS customer ON (ticket.user_id = customer.customer_id) WHERE ticket.user_id = '{$this->db->escape($cid)}' LIMIT 10 OFFSET {$offset}")->rows;
        return $tickets;
    }

    public function checkTicketExist($tid){
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket WHERE ticket_id='{$this->db->escape($tid)}'")->row['total'];
        return $check > 0;
    }

    public function getTicket($tid){
        $ticket = $this->db->query("SELECT ticket.*,cat.title AS category_title, customer.firstname, customer.lastname FROM " . DB_PREFIX . "ticket AS ticket JOIN " . DB_PREFIX . "ticket_category AS cat ON (ticket.category_id = cat.category_id) JOIN " . DB_PREFIX . "customer AS customer ON (ticket.user_id = customer.customer_id) WHERE ticket.ticket_id = '{$this->db->escape($tid)}'")->row;
        return $ticket;
    }

    public function countTicketMessages($tid){
        $total = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket_message WHERE ticket_id='{$this->db->escape($tid)}'")->row['total'];
        return $total;
    }

    public function getTicketMessages($tid){
        $messages  = $this->db->query("SELECT * FROM " . DB_PREFIX . "ticket_message WHERE ticket_id='{$this->db->escape($tid)}'")->rows;
        return $messages;
    }

    public function addMessage($cid,$tid,$message){
        $message = htmlspecialchars($message);
        $now = date("Y-m-d H:i:s");
        $this->db->query("INSERT INTO " . DB_PREFIX . "ticket_message (ticket_id,message,date,user_id,user_type) VALUES('{$this->db->escape($tid)}','{$this->db->escape($message)}','{$now}','{$this->db->escape($cid)}','customer')");
    }

    public function getCategories(){
        $categories = $this->db->query("SELECT * FROM " . DB_PREFIX . "ticket_category WHERE status = '1'")->rows;
        return $categories;
    }

    public function checkCategory($cid){
        $check = (int) $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "ticket_category WHERE category_id = '{$this->db->escape($cid)}' AND status = '1'")->row['total'];
        return $check > 0;
    }

    public function addTicket($customer_id,$title,$category_id,$message){
        $title = htmlspecialchars($title);
        $message = htmlspecialchars($message);
        $now = date("Y-m-d H:i:s");
        $this->db->query("INSERT INTO " . DB_PREFIX . "ticket (title,status,date,user_id,category_id) VALUES('{$this->db->escape($title)}','1','{$now}','{$this->db->escape($customer_id)}','{$this->db->escape($category_id)}')");
        $id = (int) $this->db->query("SELECT ticket_id FROM " . DB_PREFIX . "ticket ORDER BY ticket_id DESC")->row['ticket_id'];
        $this->addMessage($customer_id,$id,$message);
    }

    public function checkTicketStatus($tid){
        $check = (int) $this->db->query("SELECT status FROM " . DB_PREFIX . "ticket WHERE ticket_id = '{$this->db->escape($tid)}'")->row['status'];
        return $check == 1;
    }

    public function uploadPicture($file,$name,$cid,$tid){
        $fname = DIR_IMAGE . $name;
        move_uploaded_file($file,$fname);
        $now = date("Y-m-d H:i:s");
        $img = HTTP_SERVER . "image/{$name}";
        $this->db->query("INSERT INTO " . DB_PREFIX . "ticket_message (ticket_id,message,date,user_id,user_type) VALUES('{$this->db->escape($tid)}','<img src=\"{$img}\" class=\"img-fluid\">','{$now}','{$cid}','customer')");
    }
}