<?php

class ControllerAccountTickets extends Controller{
    private $error;
    public function index(){
        if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/tickets', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
        $this->load->model('account/tickets');
        $this->load->language('account/tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_date'] = $this->language->get('text_date');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_category'] = $this->language->get('text_category');
        $data['text_show'] = $this->language->get('text_show');
        $data['text_add'] = $this->language->get('text_add');
        $data['text_action'] = $this->language->get('text_action');
        $data['add_action'] = $this->url->link('account/add_ticket','',true);

        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }

        $cid = $this->customer->getId();
        $check = $this->model_account_tickets->countCustomerTickets($cid);
        if($check > 0){
            $page = (isset($this->request->get['page'])) ? (int) $this->request->get['page'] : 1;
            $tickets = $this->model_account_tickets->getTickets($cid,$page);
            $total_tickets = count($tickets);
            $data['tickets'] = array();
            foreach($tickets as $ticket){
                if($ticket['status'] == 1){
                    $ticket['status'] = $data['text_status_enable'];
                } else{
                    $ticket['status'] = $data['text_status_disable'];
                }
                $data['tickets'][] = [
                    'ticket_id' => $ticket['ticket_id'],
                    'title' => $ticket['title'],
                    'status' => $ticket['status'],
                    'date' => $ticket['date'],
                    'customer_id' => $ticket['user_id'],
                    'ticket_id' => $ticket['ticket_id'],
                    'category_title' => $ticket['category_title'],
                    'username' => $ticket['firstname'] . " " . $ticket['lastname'],
                    'href' => $this->url->link('account/show_ticket',"id={$ticket['ticket_id']}",true)
                ];
            }

            $pagination = new Pagination();
            $pagination->total = $total_tickets;
            $pagination->page = $page;
            $pagination->limit = 5;
            $pagination->url = $this->url->link('account/tickets', 'page={page}', true);

            $data['pagination'] = $pagination->render();
            $data['results'] = sprintf($this->language->get('text_pagination'), ($total_tickets) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($total_tickets - 10)) ? $total_tickets : ((($page - 1) * 10) + 10), $total_tickets, ceil($total_tickets / 10));

        } else{
            $data['error_empty'] = $this->language->get('error_empty');
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        ];
        $data['breadcrumbs'][]= [
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account')
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('account/tickets','',true)
        ];

        $data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($this->load->view('account/tickets',$data));
    }
}