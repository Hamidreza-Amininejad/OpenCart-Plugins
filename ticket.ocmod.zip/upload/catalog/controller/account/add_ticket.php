<?php

class ControllerAccountAddTicket extends Controller{
    private $error;
    public function index(){
        if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/add_ticket', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

        $this->load->model('account/tickets');
        $this->load->language('account/add_ticket');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_title'] = $this->language->get('text_title');
        $data['text_category'] = $this->language->get('text_category');
        $data['text_message'] = $this->language->get('text_message');
        $data['text_message_placeholder'] = $this->language->get('text_message_placeholder');
        $data['button_save'] = $this->language->get('button_save');
        $data['text_success_send'] = $this->language->get('text_success_send');
        $data['action'] = $this->url->link('account/add_ticket/store');
        $data['categories'] = $this->model_account_tickets->getCategories();

        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }

        if(isset($this->error['title'])){
            $data['error_title'] = $this->error['title'];
        }
        if(isset($this->error['category'])){
            $data['error_category'] = $this->error['category'];
        }
        if(isset($this->error['message'])){
            $data['error_message'] = $this->error['message'];
        }

        if(isset($this->request->post['title'])){
            $data['title'] = $this->request->post['title'];
        }
        if(isset($this->request->post['category'])){
            $data['category'] = $this->request->post['category'];
        }
        if(isset($this->request->post['message'])){
            $data['message'] = $this->request->post['message'];
        }

        $data['braedcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home','',true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account','',true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('account/add_ticket','',true)
        ];
        $data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
        $this->response->setOutput($this->load->view('account/add_ticket',$data));
    }

    public function store(){
        if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/add_ticket', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

        $this->load->model('account/tickets');
        $this->load->language('account/add_ticket');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $cid = $this->customer->getId();
        if($this->validate()){
            $title = $this->request->post['title'];
            $category = $this->request->post['category'];
            $message = $this->request->post['message'];
            $this->model_account_tickets->addTicket($cid,$title,$category,$message);
            $this->session->data['success'] = $this->language->get('text_success_send');
            $this->response->redirect($this->url->link('account/tickets','',true));
        } else{
            $data['text_title'] = $this->language->get('text_title');
            $data['text_category'] = $this->language->get('text_category');
            $data['text_message'] = $this->language->get('text_message');
            $data['text_message_placeholder'] = $this->language->get('text_message_placeholder');
            $data['button_save'] = $this->language->get('button_save');
            $data['text_success_send'] = $this->language->get('text_success_send');
            $data['action'] = $this->url->link('account/add_ticket/store');
            $data['categories'] = $this->model_account_tickets->getCategories();

            if(isset($this->session->data['success'])){
                $data['success'] = $this->session->data['success'];
                unset($this->session->data['success']);
            }

            if(isset($this->error['title'])){
                $data['error_title'] = $this->error['title'];
            }
            if(isset($this->error['category'])){
                $data['error_category'] = $this->error['category'];
            }
            if(isset($this->error['message'])){
                $data['error_message'] = $this->error['message'];
            }
    
            if(isset($this->request->post['title'])){
                $data['title'] = $this->request->post['title'];
            }
            if(isset($this->request->post['category'])){
                $data['cat'] = $this->request->post['category'];
            }
            if(isset($this->request->post['message'])){
                $data['message'] = $this->request->post['message'];
            }

            $data['braedcrumbs'] = array();
            $data['breadcrumbs'][] = [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/home','',true)
            ];
            $data['breadcrumbs'][] = [
                'text' => $this->language->get('text_account'),
                'href' => $this->url->link('account/account','',true)
            ];
            $data['breadcrumbs'][] = [
                'text' => $data['heading_title'],
                'href' => $this->url->link('account/add_ticket','',true)
            ];
            $data['column_left'] = $this->load->controller('common/column_left');
            $data['column_right'] = $this->load->controller('common/column_right');
            $data['content_top'] = $this->load->controller('common/content_top');
            $data['content_bottom'] = $this->load->controller('common/content_bottom');
            $data['footer'] = $this->load->controller('common/footer');
            $data['header'] = $this->load->controller('common/header');
            $this->response->setOutput($this->load->view('account/add_ticket',$data));
        }
    }

    protected function validate(){
        if(!isset($this->request->post['title']) || empty($this->request->post['title']) || utf8_strlen($this->request->post['title']) < 5 || utf8_strlen($this->request->post['title']) > 50){
            $this->error['title'] = $this->language->get('error_title');
        }

        if(!isset($this->request->post['category']) || empty($this->request->post['category']) || !is_numeric($this->request->post['category']) || !$this->model_account_tickets->checkCategory($this->request->post['category'])){
            exit(var_dump($this->request->post['category']));
            $this->error['category'] = $this->language->get('error_category');
        }

        if(!isset($this->request->post['message']) || utf8_strlen($this->request->post['message']) < 5 || utf8_strlen($this->request->post['message']) > 500){
            $this->error['message'] = $this->language->get('error_message');
        }

        return !$this->error;
    }
}