<?php

class ControllerAccountShowTicket extends Controller{
    private $error;
    public function index(){
        $img = $this->url->link('image/','',true);
        if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/tickets', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
        $this->load->model('account/tickets');
        $this->load->language('account/show_tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        $data['text_date'] = $this->language->get('text_date');
        $data['text_status'] = $this->language->get('text_status');
        $data['text_status_enable'] = $this->language->get('text_status_enable');
        $data['text_status_disable'] = $this->language->get('text_status_disable');
        $data['text_title'] = $this->language->get('text_title');
        $data['text_category'] = $this->language->get('text_category');
        $data['text_show'] = $this->language->get('text_show');
        $data['text_add'] = $this->language->get('text_add');
        $data['text_action'] = $this->language->get('text_action');
        $data['add_action'] = $this->url->link('account/add_ticket','',true);
        $data['text_user'] = $this->language->get('text_user');
        $data['text_message'] = $this->language->get('text_message');
        $data['text_message_placeholder'] = $this->language->get('text_message_placeholder');
        $data['text_send'] = $this->language->get('text_send');
        $data['text_picture'] = $this->language->get('text_picture');

        if($this->validate()){
            $data['upload_action'] = $this->url->link('account/show_ticket/upload',"id={$this->request->get['id']}",true);
            $cid = $this->customer->getId();
            $tid = $this->request->get['id'];
            $data['ticket'] = $this->model_account_tickets->getTicket($tid);
            $data['ticket']['status_code'] = $data['ticket']['status'];
            if($data['ticket']['status'] == 1){
                $data['ticket']['status'] = $data['text_status_enable'];
            } else{
                $data['ticket']['status'] = $data['text_status_disable'];
            }
            $data['ticket']['username'] = $data['ticket']['firstname'] . " " . $data['ticket']['lastname'];
            unset($data['ticket']['firstname']);
            unset($data['ticket']['lastname']);

            $data['action'] = $this->url->link('account/show_ticket/add',"id={$tid}",true);
            $count = $this->model_account_tickets->countTicketMessages($tid);
            if($count > 0){
                $data['messages'] = $this->model_account_tickets->getTicketMessages($tid);
            } else{
                $data['empty_messages'] = $this->language->get('empty_messages');
            }
        } else{
            if(isset($this->error['id'])){
                $data['error_warning'] = $this->error['id'];
            }
        }

        if(isset($this->session->data['success'])){
            $data['success'] = $this->session->data['success'];
            unset($this->session->data['success']);
        }

        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        ];
        $data['breadcrumbs'][]= [
            'text' => $this->language->get('text_account'),
            'href' => $this->url->link('account/account')
        ];
        $data['breadcrumbs'][] = [
            'text' => $data['heading_title'],
            'href' => $this->url->link('account/show_tickets','',true)
        ];

        $data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($this->load->view('account/show_ticket',$data));
    }

    public function add(){
        if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/tickets', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
        $this->load->model('account/tickets');
        $this->load->language('account/show_tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);

        if($this->validateMessage()){
            $cid = $this->customer->getId();
            $tid = $this->request->get['id'];
            $message = $this->request->post['message'];
            $this->model_account_tickets->addMessage($cid,$tid,$message);
            $this->session->data['success'] = $this->language->get('success_send');
            $this->response->redirect($this->url->link('account/show_ticket',"id={$tid}"));
        } else{
            $data['text_date'] = $this->language->get('text_date');
            $data['text_status'] = $this->language->get('text_status');
            $data['text_status_enable'] = $this->language->get('text_status_enable');
            $data['text_status_disable'] = $this->language->get('text_status_disable');
            $data['text_title'] = $this->language->get('text_title');
            $data['text_category'] = $this->language->get('text_category');
            $data['text_show'] = $this->language->get('text_show');
            $data['text_add'] = $this->language->get('text_add');
            $data['text_action'] = $this->language->get('text_action');
            $data['add_action'] = $this->url->link('account/add_ticket','',true);
            $data['text_user'] = $this->language->get('text_user');
            $data['text_message'] = $this->language->get('text_message');
            $data['text_message_placeholder'] = $this->language->get('text_message_placeholder');
            $data['text_send'] = $this->language->get('text_send');
            $data['text_picture'] = $this->language->get('text_picture');

            if(isset($this->error['id'])){
                $data['error_warning'] = $this->error['id'];
            } else{
                $data['action'] = $this->url->link('account/show_ticket/add',"id={$this->request->get['id']}",true);
                $data['upload_action'] = $this->url->link('account/show_ticket/upload',"id={$this->request->get['id']}",true);
                $cid = $this->customer->getId();
                $tid = $this->request->get['id'];
                $data['ticket'] = $this->model_account_tickets->getTicket($tid);
                $data['ticket']['status_code'] = $data['ticket']['status'];
                if($data['ticket']['status'] == 1){
                    $data['ticket']['status'] = $data['text_status_enable'];
                } else{
                    $data['ticket']['status'] = $data['text_status_disable'];
                }
                $data['ticket']['username'] = $data['ticket']['firstname'] . " " . $data['ticket']['lastname'];
                unset($data['ticket']['firstname']);
                unset($data['ticket']['lastname']);
                $count = $this->model_account_tickets->countTicketMessages($tid);
                if($count > 0){
                    $data['messages'] = $this->model_account_tickets->getTicketMessages($tid);
                } else{
                    $data['empty_messages'] = $this->languuage->get('empty_messages');
                }
            }
            if(isset($this->error['message'])){
                $data['error_message'] = $this->error['message'];
            }
            if(isset($this->session->data['success'])){
                $data['success'] = $this->session->data['success'];
                unset($this->session->data['success']);
            }
            if(isset($this->error['status'])){
                $data['error_status'] = $this->error['status'];
            }

            $data['breadcrumbs'] = array();
            $data['breadcrumbs'][] = [
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/home')
            ];
            $data['breadcrumbs'][]= [
                'text' => $this->language->get('text_account'),
                'href' => $this->url->link('account/account')
            ];
            $data['breadcrumbs'][] = [
                'text' => $data['heading_title'],
                'href' => $this->url->link('account/show_tickets','',true)
            ];

            $data['column_left'] = $this->load->controller('common/column_left');
            $data['column_right'] = $this->load->controller('common/column_right');
            $data['content_top'] = $this->load->controller('common/content_top');
            $data['content_bottom'] = $this->load->controller('common/content_bottom');
            $data['footer'] = $this->load->controller('common/footer');
            $data['header'] = $this->load->controller('common/header');

            $this->response->setOutput($this->load->view('account/show_ticket',$data));
        }
    }

    public function upload(){
        if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/tickets', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
        $this->load->model('account/tickets');
        $this->load->language('account/show_tickets');
        $data['heading_title'] = $this->language->get('heading_title');
        $this->document->setTitle($data['heading_title']);
        if($this->uploadValidate()){
            $now = time();
            $cid = $this->customer->getId();
            $type = @strtolower(end(explode('.',$this->request->files['picture']['name'])));
            $fname = "{$cid}-{$now}.{$type}";
            $file = $this->request->files['picture']['tmp_name'];
            $tid = $this->request->get['id'];
            $this->model_account_tickets->uploadPicture($file,$fname,$cid,$tid);
            $this->session->data['success'] = $this->language->get('text_succes_upload');
            $this->response->redirect($this->url->link('account/show_ticket',"id={$tid}",true));
        } else{
            if(isset($this->error['id'])){
                $this->response->redirect($this->url->link('account/tickets','',true));
            } else{
                $this->session->data['success'] = $this->error['pic'];
                $tid = $this->request->get['id'];
                $this->response->redirect($this->url->link('account/show_ticket',"id={$tid}",true));
            }
        }
    }

    protected function validate(){
        $cid = $this->customer->getId();
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id']) || !$this->model_account_tickets->checkTicketExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_empty');
        } elseif(!$this->model_account_tickets->checkCustomerAccess($cid,$this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_access');
        }
        
        return !$this->error;
    }

    protected function validateMessage(){
        $cid = $this->customer->getId();
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id']) || !$this->model_account_tickets->checkTicketExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_empty');
        } elseif(!$this->model_account_tickets->checkCustomerAccess($cid,$this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_access');
        }
        if(!isset($this->request->post['message']) || utf8_strlen($this->request->post['message']) < 5 || utf8_strlen($this->request->post['message']) > 500){
            $this->error['message'] = $this->language->get('error_message');
        }
        if(@!$this->model_account_tickets->checkTicketStatus($this->request->get['id'])){
            $this->error['status'] = $this->language->get('error_status');
        }

        return !$this->error;
    }

    protected function uploadValidate(){
        $cid = $this->customer->getId();
        if(!isset($this->request->get['id']) || empty($this->request->get['id']) || !is_numeric($this->request->get['id']) || !$this->model_account_tickets->checkTicketExist($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_empty');
        }
        elseif(!$this->model_account_tickets->checkTicketStatus($this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_status');
        }
        elseif(!$this->model_account_tickets->checkCustomerAccess($cid,$this->request->get['id'])){
            $this->error['id'] = $this->language->get('error_access');
        }
        if(!isset($this->request->files['picture'])){
            $this->error['pic'] = $this->language->get('error_empty_pic');
        }
        elseif(@strtolower(end(explode('.',$this->request->files['picture']['name']))) !== 'png' && @strtolower(end(explode('.',$this->request->files['picture']['name']))) !== 'jpg' && @strtolower(end(explode('.',$this->request->files['picture']['name']))) !== 'jpeg'){
            $this->error['pic'] = $this->language->get('error_type_pic');
        }
        elseif((int) $this->request->files['picture']['size'] > 1000000 || (int) $this->request->files['picture']['size'] < 1000){
            $this->error['pic'] = $this->language->get('error_size_pic');
        }
        return !$this->error;
    }
}