<?php

$_['heading_title']                 = 'افزودن تیکت';

// Text
$_['text_account']                  = 'حساب کاربری';
$_['text_title']                    = 'عنوان';
$_['text_category']                 = 'دسته بندی';
$_['text_message']                  = 'پیام';
$_['text_message_placeholder']      = 'پیام خود را وارد کنید';
$_['button_save']                   = 'ارسال پیام';
$_['text_success_send']             = 'تیکت شما با موفقیت ایجاد شد';

// Errors

$_['error_title']                   = 'عنوان تیکت باید متنی بین 5 تا 50 کاراکتر باشد';
$_['error_category']                = 'دسته بندی به درستی انتخاب نشده است';
$_['error_message']                 = 'پیام وارد شده باید بین 5 تا 500 کاراکتر باشد';