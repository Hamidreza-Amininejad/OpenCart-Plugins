<?php

$_['heading_title']                 = 'تیکت ها';

// Text
$_['text_account']                     = 'حساب کاربری';
$_['text_date']                     = 'تاریخ ایجاد';
$_['text_status']                   = 'وضعیت';
$_['text_status_enable']            = 'فعال';
$_['text_status_disable']           = 'غیرفعال';
$_['text_title']                    = 'عنوان';
$_['text_category']                 = 'دسته بندی';
$_['text_show']                     = 'مشاهده';
$_['text_add']                      = 'تیکت جدید';
$_['text_action']                   = 'عملیات';

// Errors
$_['error_empty']                   = 'هیچ تیکتی برای نمایش وجود ندارد';