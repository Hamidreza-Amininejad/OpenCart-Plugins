<?php
class InstallExtension{
    public $admin_path;
    public $catalog_path;
    public function __construct(){
        $this->admin_path = DIR_APPLICATION;
        $this->catalog_path = DIR_APPLICATION . '../catalog/';

        $this->admin_controller_columnleft();
        $this->admin_language_columnleft();
        $this->catalog_controller_account_account();
        $this->catalog_extension_module_account();
        $this->catalog_language_account_account();
        $this->catalog_language_extension_module_account();
        $this->catalog_view_account_account();
        $this->catalog_view_extension_module_account();
    }
    public function editFile($file_path,$search,$replace){
        if(!file_exists($file_path)){
            return false;
        }
        $file = fopen($file_path,"r");
        $fdata = fread($file,filesize($file_path));
        fclose($file);
        unlink($file_path);
        $result = str_replace(base64_decode($search),base64_decode($replace),$fdata);
        $file = fopen($file_path,"a+");
        fwrite($file,$result);
        fclose($file);
    }

    public function admin_controller_columnleft(){
        $file = "{$this->admin_path}/controller/common/column_left.php";
        $search = "aWYgKCRjYXRhbG9nKSB7DQoJCQkJJGRhdGFbJ21lbnVzJ11bXSA9IGFycmF5KA0KCQkJCQknaWQnICAgICAgID0+ICdtZW51LWNhdGFsb2cnLA0KCQkJCQknaWNvbicJICAgPT4gJ2ZhLXRhZ3MnLCANCgkJCQkJJ25hbWUnCSAgID0+ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X2NhdGFsb2cnKSwNCgkJCQkJJ2hyZWYnICAgICA9PiAnJywNCgkJCQkJJ2NoaWxkcmVuJyA9PiAkY2F0YWxvZw0KCQkJCSk7CQkNCgkJCX0";
        $replace = "aWYgKCRjYXRhbG9nKSB7DQoJCQkJJGRhdGFbJ21lbnVzJ11bXSA9IGFycmF5KA0KCQkJCQknaWQnICAgICAgID0+ICdtZW51LWNhdGFsb2cnLA0KCQkJCQknaWNvbicJICAgPT4gJ2ZhLXRhZ3MnLCANCgkJCQkJJ25hbWUnCSAgID0+ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X2NhdGFsb2cnKSwNCgkJCQkJJ2hyZWYnICAgICA9PiAnJywNCgkJCQkJJ2NoaWxkcmVuJyA9PiAkY2F0YWxvZw0KCQkJCSk7CQkNCgkJCX0NCgkJCQ0KCQkJLy8gVGlja2V0cw0KDQoJCQkkdGlja2V0cyA9IGFycmF5KCk7DQoNCgkJCWlmICgkdGhpcy0+dXNlci0+aGFzUGVybWlzc2lvbignYWNjZXNzJywgJ3RpY2tldHMvdGlja2V0cycpKSB7CQkNCgkJCQkkdGlja2V0c1tdID0gYXJyYXkoDQoJCQkJCSduYW1lJwkgICA9PiAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF90aWNrZXRzJyksDQoJCQkJCSdocmVmJyAgICAgPT4gJHRoaXMtPnVybC0+bGluaygndGlja2V0cy90aWNrZXRzJywgJ3Rva2VuPScgLiAkdGhpcy0+c2Vzc2lvbi0+ZGF0YVsndG9rZW4nXSwgdHJ1ZSksDQoJCQkJCSdjaGlsZHJlbicgPT4gYXJyYXkoKQkJDQoJCQkJKTsJCQkJCQ0KCQkJfQ0KCQkJDQoJCQlpZiAoJHRoaXMtPnVzZXItPmhhc1Blcm1pc3Npb24oJ2FjY2VzcycsICd0aWNrZXRzL2NhdGVnb3J5JykpIHsJCQ0KCQkJCSR0aWNrZXRzW10gPSBhcnJheSgNCgkJCQkJJ25hbWUnCSAgID0+ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X3RpY2tldHNfY2F0ZWdvcnknKSwNCgkJCQkJJ2hyZWYnICAgICA9PiAkdGhpcy0+dXJsLT5saW5rKCd0aWNrZXRzL2NhdGVnb3J5JywgJ3Rva2VuPScgLiAkdGhpcy0+c2Vzc2lvbi0+ZGF0YVsndG9rZW4nXSwgdHJ1ZSksDQoJCQkJCSdjaGlsZHJlbicgPT4gYXJyYXkoKQkJDQoJCQkJKTsJCQkJCQ0KCQkJfQkNCgkJCQ0KCQkJCQkNCgkJCWlmICgkdGlja2V0cykgewkJCQ0KCQkJCSRkYXRhWydtZW51cyddW10gPSBhcnJheSgNCgkJCQkJJ2lkJyAgICAgICA9PiAnbWVudS10aWNrZXRzJywNCgkJCQkJJ2ljb24nCSAgID0+ICdmYS1lbnZlbG9wZScsIA0KCQkJCQknbmFtZScJICAgPT4gJHRoaXMtPmxhbmd1YWdlLT5nZXQoJ3RleHRfdGlja2V0cycpLA0KCQkJCQknaHJlZicgICAgID0+ICcnLA0KCQkJCQknY2hpbGRyZW4nID0+ICR0aWNrZXRzDQoJCQkJKTsJCQ0KCQkJfQ";
        $this->editFile($file,$search,$replace);
    }

    public function admin_language_columnleft(){
        $file = "{$this->admin_path}/language/fa-ir/common/column_left.php";
        $search = "JF9bJ3RleHRfb3RoZXJfc3RhdHVzJ10gICAgICAgICAgICAgID0gJ9mI2LbYuduM2Kog2YfYp9uMINiv24zar9ixJzs";
        $replace = "JF9bJ3RleHRfb3RoZXJfc3RhdHVzJ10gICAgICAgICAgICAgID0gJ9mI2LbYuduM2Kog2YfYp9uMINiv24zar9ixJzsNCiRfWyd0ZXh0X3RpY2tldHMnXSAgICAgICAgICAgICAgICAgICA9ICfYqtuM2qnYqiDZh9inJzsNCiRfWyd0ZXh0X3RpY2tldHNfY2F0ZWdvcnknXSAgICAgICAgICA9ICfZhdmI2LbZiNi52KfYqic7IA";
        $this->editFile($file,$search,$replace);
    }

    public function catalog_controller_account_account(){
        $file = "{$this->catalog_path}/controller/account/account.php";
        $search = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTs";
        $replace = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTsNCgkJJGRhdGFbJ3RleHRfdGlja2V0cyddID0gJHRoaXMtPmxhbmd1YWdlLT5nZXQoJ3RleHRfdGlja2V0cycpOw0KCQkkZGF0YVsndGV4dF90aWNrZXRzX3Nob3cnXSA9ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X3RpY2tldHNfc2hvdycpOw0KCQkkZGF0YVsndGV4dF90aWNrZXRzX2FkZCddID0gJHRoaXMtPmxhbmd1YWdlLT5nZXQoJ3RleHRfdGlja2V0c19hZGQnKTs";
        $this->editFile($file,$search,$replace);

        $search = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7";
        $replace = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7DQoJCSRkYXRhWyd0aWNrZXRzX3Nob3cnXSA9ICR0aGlzLT51cmwtPmxpbmsoJ2FjY291bnQvdGlja2V0cycsJycsdHJ1ZSk7DQoJCSRkYXRhWyd0aWNrZXRzX2FkZCddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9hZGRfdGlja2V0JywnJyx0cnVlKTs";
        $this->editFile($file,$search,$replace);
    }

    public function catalog_extension_module_account(){
        $file = "{$this->catalog_path}/controller/extension/module/account.php";
        $search = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTs";
        $replace = "JGRhdGFbJ3RleHRfcmVjdXJyaW5nJ10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF9yZWN1cnJpbmcnKTsNCgkJJGRhdGFbJ3RleHRfdGlja2V0c19zaG93J10gPSAkdGhpcy0+bGFuZ3VhZ2UtPmdldCgndGV4dF90aWNrZXRzX3Nob3cnKTsNCgkJJGRhdGFbJ3RleHRfdGlja2V0c19hZGQnXSA9ICR0aGlzLT5sYW5ndWFnZS0+Z2V0KCd0ZXh0X3RpY2tldHNfYWRkJyk7";
        $this->editFile($file,$search,$replace);

        $search = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7";
        $replace = "JGRhdGFbJ3JlY3VycmluZyddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9yZWN1cnJpbmcnLCAnJywgdHJ1ZSk7DQoJCSRkYXRhWyd0aWNrZXRzX3Nob3cnXSA9ICR0aGlzLT51cmwtPmxpbmsoJ2FjY291bnQvdGlja2V0cycsJycsdHJ1ZSk7DQoJCSRkYXRhWyd0aWNrZXRzX2FkZCddID0gJHRoaXMtPnVybC0+bGluaygnYWNjb3VudC9hZGRfdGlja2V0JywnJyx0cnVlKTs";
        $this->editFile($file,$search,$replace);
    }

    public function catalog_language_account_account(){
        $file = "{$this->catalog_path}/language/fa-ir/account/account.php";
        $search = "JF9bJ3RleHRfdHJhbnNhY3Rpb25zJ10gID0gJ9iq2LHYp9qp2YbYtCDZh9inJzs";
        $replace = "JF9bJ3RleHRfdHJhbnNhY3Rpb25zJ10gID0gJ9iq2LHYp9qp2YbYtCDZh9inJzsNCiRfWyd0ZXh0X3RpY2tldHMnXSAgICAgICA9ICfYqtuM2qnYqiDZh9inJzsNCiRfWyd0ZXh0X3RpY2tldHNfc2hvdyddICA9ICfZhdi02KfZh9iv2Ycg24wg2KrbjNqp2Kog2YfYpyc7DQokX1sndGV4dF90aWNrZXRzX2FkZCddICAgPSAn2KfZgdiy2YjYr9mGINiq24zaqdiqJzs";
        $this->editFile($file,$search,$replace);
    }

    public function catalog_language_extension_module_account(){
        $file = "{$this->catalog_path}/language/fa-ir/extension/module/account.php";
        $search = "JF9bJ3RleHRfcmVjdXJyaW5nJ10gICA9ICfZvtix2K/Yp9iu2Kog2YfYp9uMINiv2YjYsdmHINin24wnOw";
        $replace = "JF9bJ3RleHRfcmVjdXJyaW5nJ10gICA9ICfZvtix2K/Yp9iu2Kog2YfYp9uMINiv2YjYsdmHINin24wnOw0KJF9bJ3RleHRfdGlja2V0c19zaG93J10gPSAn2KrbjNqp2Kog2YfYpyc7DQokX1sndGV4dF90aWNrZXRzX2FkZCddICA9ICfYqtuM2qnYqiDYrNiv24zYryc7";
        $this->editFile($file,$search,$replace);
    }

    public function catalog_view_account_account(){
        $file = "{$this->catalog_path}/view/theme/default/template/account/account.tpl";
        $search = "PGxpPjxhIGhyZWY9Ijw/cGhwIGVjaG8gJHJlY3VycmluZzsgPz4iPjw/cGhwIGVjaG8gJHRleHRfcmVjdXJyaW5nOyA/PjwvYT48L2xpPg0KICAgICAgPC91bD4";
        $replace = "PGxpPjxhIGhyZWY9Ijw/cGhwIGVjaG8gJHJlY3VycmluZzsgPz4iPjw/cGhwIGVjaG8gJHRleHRfcmVjdXJyaW5nOyA/PjwvYT48L2xpPg0KICAgICAgPC91bD4NCg0KICAgICAgPGgyPjw/cGhwIGVjaG8gJHRleHRfdGlja2V0cyA/PjwvaDI+DQogICAgICA8dWwgY2xhc3M9Imxpc3QtdW5zdHlsZWQiPg0KICAgICAgICA8bGk+PGEgaHJlZj0iPD9waHAgZWNobyAkdGlja2V0c19zaG93ID8+Ij48P3BocCBlY2hvICR0ZXh0X3RpY2tldHNfc2hvdyA/PjwvYT48L2xpPg0KICAgICAgICA8bGk+PGEgaHJlZj0iPD9waHAgZWNobyAkdGlja2V0c19hZGQgPz4iPjw/cGhwIGVjaG8gJHRleHRfdGlja2V0c19hZGQgPz48L2E+PC9saT4NCiAgICAgIDwvdWw+";
        $this->editFile($file,$search,$replace);
    }

    public function catalog_view_extension_module_account(){
        $file = "{$this->catalog_path}/view/theme/default/template/extension/module/account.tpl";
        $search = "PGEgaHJlZj0iPD9waHAgZWNobyAkYWRkcmVzczsgPz4iIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPjw/cGhwIGVjaG8gJHRleHRfYWRkcmVzczsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJHdpc2hsaXN0OyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF93aXNobGlzdDsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJG9yZGVyOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9vcmRlcjsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJGRvd25sb2FkOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9kb3dubG9hZDsgPz48L2E+PGEgaHJlZj0iPD9waHAgZWNobyAkcmVjdXJyaW5nOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9yZWN1cnJpbmc7ID8+PC9hPiA8YSBocmVmPSI8P3BocCBlY2hvICRyZXdhcmQ7ID8+IiBjbGFzcz0ibGlzdC1ncm91cC1pdGVtIj48P3BocCBlY2hvICR0ZXh0X3Jld2FyZDsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJHJldHVybjsgPz4iIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPjw/cGhwIGVjaG8gJHRleHRfcmV0dXJuOyA/PjwvYT4gPGEgaHJlZj0iPD9waHAgZWNobyAkdHJhbnNhY3Rpb247ID8+IiBjbGFzcz0ibGlzdC1ncm91cC1pdGVtIj48P3BocCBlY2hvICR0ZXh0X3RyYW5zYWN0aW9uOyA/PjwvYT4gPGEgaHJlZj0iPD9waHAgZWNobyAkbmV3c2xldHRlcjsgPz4iIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPjw/cGhwIGVjaG8gJHRleHRfbmV3c2xldHRlcjsgPz48L2E+";
        $replace = "PGEgaHJlZj0iPD9waHAgZWNobyAkYWRkcmVzczsgPz4iIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPjw/cGhwIGVjaG8gJHRleHRfYWRkcmVzczsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJHdpc2hsaXN0OyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF93aXNobGlzdDsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJG9yZGVyOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9vcmRlcjsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJGRvd25sb2FkOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9kb3dubG9hZDsgPz48L2E+PGEgaHJlZj0iPD9waHAgZWNobyAkcmVjdXJyaW5nOyA/PiIgY2xhc3M9Imxpc3QtZ3JvdXAtaXRlbSI+PD9waHAgZWNobyAkdGV4dF9yZWN1cnJpbmc7ID8+PC9hPiA8YSBocmVmPSI8P3BocCBlY2hvICRyZXdhcmQ7ID8+IiBjbGFzcz0ibGlzdC1ncm91cC1pdGVtIj48P3BocCBlY2hvICR0ZXh0X3Jld2FyZDsgPz48L2E+IDxhIGhyZWY9Ijw/cGhwIGVjaG8gJHJldHVybjsgPz4iIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPjw/cGhwIGVjaG8gJHRleHRfcmV0dXJuOyA/PjwvYT4gPGEgaHJlZj0iPD9waHAgZWNobyAkdHJhbnNhY3Rpb247ID8+IiBjbGFzcz0ibGlzdC1ncm91cC1pdGVtIj48P3BocCBlY2hvICR0ZXh0X3RyYW5zYWN0aW9uOyA/PjwvYT4gPGEgaHJlZj0iPD9waHAgZWNobyAkbmV3c2xldHRlcjsgPz4iIGNsYXNzPSJsaXN0LWdyb3VwLWl0ZW0iPjw/cGhwIGVjaG8gJHRleHRfbmV3c2xldHRlcjsgPz48L2E+DQogIA0KICA8YSBocmVmPSI8P3BocCBlY2hvICR0aWNrZXRzX3Nob3c7ID8+IiBjbGFzcz0ibGlzdC1ncm91cC1pdGVtIj48P3BocCBlY2hvICR0ZXh0X3RpY2tldHNfc2hvdyA/PjwvYT4NCiAgPGEgaHJlZj0iPD9waHAgZWNobyAkdGlja2V0c19hZGQ7ID8+IiBjbGFzcz0ibGlzdC1ncm91cC1pdGVtIj48P3BocCBlY2hvICR0ZXh0X3RpY2tldHNfYWRkID8+PC9hPg";
        $this->editFile($file,$search,$replace);
    }

}

$install = new InstallExtension();